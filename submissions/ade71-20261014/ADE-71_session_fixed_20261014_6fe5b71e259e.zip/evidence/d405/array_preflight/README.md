# 배열 사전 검사만 통과

float32 depth/bool mask의 배열 저장 재로드 결과 10개이며 FramePacket 세션이 아니다. 보고서의 originals 경로는 원 실행 이력이다. 원본 3개 파일은 raw/depth_original.zip 안에만 있다. 65535를 물리적으로 유효하다고 승인한 결과가 아니다.
