# 실제 입력 차단

INTAKE_BLOCKED·종료 1이다. 정상 FramePacket 세션·Point Cloud 없음. validation.json은 원 실행의 절대 경로를 포함한 이력이다. evidence 원본 사본은 중복 포장하지 않았고 raw/depth_original.zip에서 외부 새 intake에만 준비한다.
