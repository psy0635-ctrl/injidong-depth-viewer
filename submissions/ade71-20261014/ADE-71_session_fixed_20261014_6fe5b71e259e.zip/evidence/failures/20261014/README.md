These are failed harness runs, NOT normal sessions. The initial intake location was rejected by the existing path policy. Failed binary outputs are not packaged here.
