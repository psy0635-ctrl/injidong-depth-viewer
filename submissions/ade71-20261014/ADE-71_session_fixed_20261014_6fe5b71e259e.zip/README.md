# ADE-71 수정본 팀장 검토 제출 — 2026-10-14

완료 범위: PC 파일 처리·합성 검증·실제 입력 차단, ZIP 독립 검토의 F1–F4 수정. 실제 D405 세션/Point Cloud·Android/SDK·부피·중량은 미완료. 팀장 승인 미확보. 공용 계약 사본 변경은 강석현 검토 필요.

branch codex/ade-71-stage1-20261013, HEAD a6180a6aca48de5c98b3a4d81619f64cea573118. HEAD는 10/3 문서 커밋이며 이번 구현 커밋이 아니다. 구현은 미커밋/미추적 상태. commit/push·Linear 변경·메시지 발송 없음.

새 소스 시험: 104 pass / 0 failure / 2 skip, 106개. 새 회귀16(15pass/1skip), contract28, pipeline21, 이전회귀15(14pass/1skip), replay10, viewer16. F2를 실제 child CLI 종료1로 추가 확인한 선택1은 중복 합산하지 않는다. 과거67/68·구현63·이전14+9·해제본 재실행은 별도 실행 범위다. logs의 이전 날짜 기록은 역사 근거다. 새 시험은 *_ade71_zip_fixes_* 로그와 docs/ADE-71-zip-fixes-20261014.md를 따른다.

skip2: 기존 test_auxiliary_jsonl_symlink_escape(annotations.jsonl 파일 링크), 새 test_f3_symlink_alias_if_permitted(입력 디렉터리 링크). WinError1314 생성 권한 부족으로 실제 링크 시험 미완료. 권한 변경 없음. Windows junction 별칭 시험은 실제 생성/거부 통과. 타 OS 결과로 Windows skip을 대체하지 않는다.

환경: Windows10.0.26200, Python3.11.9, NumPy2.3.5, Pillow12.3.0; 공용 로더 영향 시험은 기존 Matplotlib 환경. 기존 C:\study\injidong-depth-viewer\.venv\Scripts\python.exe 재사용이며 새 환경 설치 성공이 아니다. requirements-package.txt/requirements.txt는 PC 최소 실행, requirements-viewer.txt는 viewer 영향 시험의 추가 의존성.

새 관리 세션은 .ade71-run.json/.ade71-session.json과 최종 .ade71-complete.json을 포함한다. validation passed/processing success 문자열만으로 완료를 인수하지 않는다. contract.iter_frames/load_frame, viewer_data.read_session, pipeline.process_frame/verify_session, replay 및 session_boundary.load_processing_result를 사용한다. 격리 실패 잔존 파일도 완료 sidecar 부재로 거부된다. core1.0.0의 metadata/frames/5스키마는 그대로다. sidecar는 팀 규격·물리 근거·인증·팀장 승인이 아니다.

보호 원본 src/contract.py는 protected_reference/src/contract.py에 byte-for-byte 보존했다. 활성 src/contract.py는 guard 연결 변경 사본이며 원본 checksum과 의도적으로 다르다. 기존 SHA256SUMS.txt를 수정하지 않았다. PROTECTED_FILE_MAP.json에 원본21개 매핑과 변경1개를 명시한다. 5스키마 및 다른 보호 원본은 동일하다. review/diffs를 검토한다.

합성 기대: raw[[1000,1000],[1000,0]], scale.001, fx=fy100,cx=cy0 → float32 points_m [[0,0,1],[.01,0,1],[0,.01,1]] m, 행 우선3점, 10회 재생·전체 값/hash 비교·종료0. 실제 D405 기대: INTAKE_BLOCKED·종료1, 정상 세션/점군 없음. 정밀 내참수·Brown Conrady 보정·장비/profile/calibration 출처·65535 의미가 미확인이다. 미저장 시간은 내부 ns/clock_domain/origin 모두 null이며 변환 시각으로 대체하지 않는다. pose 부재만으로 camera 좌표 처리를 모두 금지하지 않는다.

실제 완료에는 REQUESTS.md의 자료가 현재 raw hash/frame/profile에 연결되어야 한다. small_v1, 강석현 제작/실측·도형준 실제 촬영, 모바일 Galaxy S23 FE 조합/정렬·mask는 이가영 인수 근거를 따른다. 공용0.2.0은 미수신/호환성 미확인. volume=null 및 모델 미준비 유지.

원본 depth_original.zip 한 개만 포함했다. 내부 원본 파일의 별도 중복 포장, venv/cache/Git/키/토큰은 제외했다. 옛 제출 ZIP이나 submissions 폴더 전체는 포함하지 않았다. 실패 증거는 evidence/failures이고 정상 outputs와 구분한다. 이번 시작447개 목록/hash로 허용 변경 범위만 검증하며 과거504개 보존은 확인 불가다.

차단 실행 evidence의 원본3개 복사본은 ORIGINAL_MEMBER_MAP.json을 통해 단일 raw/depth_original.zip의 해당 멤버/hash로 연결한다. 차단 report의 과거 임시 source 경로는 기록이며, 재실행은 prepare_d405_intake로 새로운 외부 intake를 만든다.

FILE_SHA256SUMS.txt는 자기 자신만 제외한다. 외부 ZIP SHA256/크기/파일수·CRC·실제 별도 해제본 검증은 ZIP 옆 PACKAGING_VERIFICATION.json에 기록한다(자기 ZIP hash를 내부에 포함하는 순환 방지).

```powershell
$adePython = 'C:\study\injidong-depth-viewer\.venv\Scripts\python.exe'
$adeExtracted = 'C:\Users\AISW-5~1\AppData\Local\Temp\ade71_fixed_zip_validation__asult6t\extracted'
Set-Location -LiteralPath $adeExtracted
& $adePython -B -X utf8 scripts\validate_ade71_zip_fixes.py `
  --output-root 'C:\Users\AISW-5~1\AppData\Local\Temp\ade71_fixed_zip_validation__asult6t\minimum_runs' --regressions
$LASTEXITCODE # supervisor0, 내부 합성0 / 실제 D405차단1; skip은 통과 아님
```

해제 폴더가 달라지면 adeExtracted를 실제 경로로 설정한다. 최소 supervisor는 프로젝트 import를 해제본으로 확인하고 D405 원본은 새 외부 temp intake에 준비한다. capture 코드를 실행하지 않는다. 아래 경로의 새 정상 output은 소스 검증 기록이며, 재현 CLI는 항상 새 output을 만든다.
outputs/ade71_zip_fixes_20261014/run_cb6c2c93bbe249ab99f9dc38bb11706c
