# 담당자별 자료 요청문 — 발송하지 않은 검토 자료

최종 검토서의 요청표를 그대로 사용한다. 각 자료는 현재 촬영본의 raw SHA-256·원본 프레임 인덱스·활성 profile/calibration과 대응해야 한다. 다른 촬영본의 자료를 기존 입력에 소급 적용하지 않는다.

현재 원본 ZIP SHA-256: `c7db1884aa5a78fd4fd634153e9575912d762000a7aa0aa1ad7acee66889e6e2`

현재 raw depth10.npz SHA-256: `61de8af2f76ff04e4bac639b7f1fe4f4a07b638534dec2ac8866deb657ad29f0`

현재 source_frame_index=0..9, raw uint16 10×480×640. 스크립트의 640×480 Z16 30 설정은 확인했지만 실제 장비/profile/calibration 식별은 미확인이다. 기존 raw에는 공용 frame/session/specimen ID·촬영 시각·RGB/pose가 없다. 가짜 값을 생성하지 않는다.


필수와 조건부를 구분한다. 모든 자료는 해당 촬영본의 원본 해시·session/frame/source_frame_index와 연결해 받아야 한다. 메시지는 발송하지 않았다.

| 필수 항목 / 적용 조건 | 해당 촬영본과 연결할 근거 | 받을 사람 |
|---|---|---|
| **필수:** 원본 raw 및 프레임 대응 | ZIP/NPZ SHA-256, key/dtype/N×H×W, source_frame_index ↔ frame/session ID. 기존 D405 receipt와 다른 촬영은 새 receipt | 도형준; 모바일은 이가영 |
| **필수:** scale와 optical_axis_z | 실제 SDK get_depth_scale 값/출력, 실행 코드·SDK/profile 정보, 해당 raw SHA-256. ray distance이면 먼저 보정한 Z 산출 근거 | 강석현 backend 검토, 도형준 수집; 모바일 이가영 전달 |
| **필수:** 정밀 Depth 내참수 | width/height/fx/fy/cx/cy 정밀 수치, 활성 Depth profile ID·calibration ID·원본 파일/프레임 범위. 반올림 콘솔 문자열 불가 | 도형준 제공, 강석현 확인 |
| **필수:** rectified_pinhole/왜곡 처리 | 해당 장비/profile의 원본 왜곡 모델·정밀 계수·보정/rectification 경로, 적용 intrinsics/calibration ID, 변환 전후 raw 대응. Brown Conrady의 자동 호환 선언 불가 | 강석현 확인, 도형준 원본 |
| **필수:** 장비/profile 출처 | 모델/serial/FW/SDK/OS·활성 Depth 설정·profile 식별과 해당 session/raw 해시를 함께 저장한 SDK 로그. D405라는 전달 표기만으로 대체 불가 | 도형준, 강석현; Android 조합은 이가영 |
| **해당 raw에 65535 존재 시 필수:** 의미/정책 | 해당 profile에서 65535가 invalid인지 valid 거리인지의 SDK/장비 근거와 정책 버전, source_sha256/profile/calibration ID | 강석현 확인, 도형준 수집; 모바일 이가영 |
| **신규 촬영 인수:** 원본 capture/host_receive 시간 | 프레임별 ns 문자열·clock_domain/origin, source frame 대응. 기존 미저장본은 fully-null 객체 유지하며 소급 생성 금지 | 강석현 backend·도형준; 모바일 이가영 |
| **데이터셋/평가 인수:** small_v1 시편/조건 | 실제 물리 specimen ID·촬영표·측정 치수/단위·조건·원본 해시. 20mm cube/빈 바닥 예비 자료 먼저. 기존 원본 미확인은 null | 강석현 시편 기준·예비 확인, 도형준 실제 촬영 |
| **실제 모바일 주장 시 필수:** Galaxy S23 FE 조합 | 실제 모델번호·Android/One UI·SDK/USB·전력/권한·성공/오류 로그와 ADE-100 session/frame/raw. PC 전달/saved/synthetic 구분 | 이가영 |
| **RGB 기반 라벨/mask 인수 시 필수:** 정렬·pair 근거 | 원본/정렬 PNG 별도 해시·RGB8·images.jsonl, Depth frame/calibration ID, 원본 시각·시계 매핑/대응과 실제 projection/alignment 방법. 크기만 맞춤 불가 | 이가영 자료·강석현 계약 검토 |
| **target 사용 시 필수:** frame-bound mask receipt | H×W bool NPZ/해시, frame/session/specimen, source/version/purpose와 정렬 근거 해시. model_output은 model/annotation 버전과 동일 입력 연결, manual은 별도 파일 | 이가영 |
| **세계 좌표/다중 시점 사용 시 조건부:** pose/sync | camera→world 보정·pose/capture 시각·clock mapping/evidence와 offset/uncertainty/tolerance. orientation으로 위치 생성 불가 | 강석현·도형준; IMU 원본은 이가영 |
| **부피 계산 시 조건부:** support/basis/footprint/coverage/가정 | 같은 FramePacket/target의 지지면·plane basis·측정 footprint·grid·완전 관측/방법 제한 근거 | 강석현 기준 검토, 도형준 촬영, 이가영 mask; 박수용 후처리 |
| **중량 정확도 주장 시 조건부:** 모델·실측 g | 실제 specimen별 모델/feature 버전·학습/독립 split·실측 기기/방법/해시. 미확보 0g 생성 금지 | 이가영 모델·평가, 강석현 실측 기준 |
| **패키지 호환성 확인 시 필수:** 공용 0.2.0 묶음 | software/injidong_week3·docs/week3_quickstart.md·배포 해시·core1.0.0·지원/호환 목록. 미수신 상태 유지 | 강석현 |

촬영 시각·pose·시편/RGB 미확보는 core의 nullable 규칙을 따른다. 현재 실제 D405 정식 변환의 차단 원인은 **정밀 내참수·광학/단위 보정 근거·장비/profile 출처·65535 의미**이며, 단순히 timestamp가 없어서라고 보고하지 않는다.


## 2026-10-14 추가 — 공용 변경 사본 검토

강석현에게 활성 contract.py의 완료/상대경로 guard 연결 diff, 원본 checksum 보존 매핑, 외부 legacy 세션과 0.2.0 호환 영향을 검토받아야 한다. 원본은 protected_reference/src/contract.py다. 이 요청은 발송하지 않았다. 과거504개 전체 보존의 기준/후 목록은 미수신이므로 확정하지 않는다.
