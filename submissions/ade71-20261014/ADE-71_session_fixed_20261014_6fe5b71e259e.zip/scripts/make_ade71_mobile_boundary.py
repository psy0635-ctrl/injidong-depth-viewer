"""Saved/synthetic module handoff example; no Android, camera, real RGB or specimen."""
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from depth_preflight import digest, write_json_new
from session_pipeline import run_conversion
from viewer_data import read_session


if __name__ == '__main__':
    run, _ = run_conversion(ROOT / 'examples/ade71_session_intake/synthetic/basis.json',
                            ROOT / 'outputs/ade71_mobile_fixture_build', 1)
    dest = ROOT / 'examples/ade71_mobile_boundary_synthetic'
    shutil.copytree(run / 'session', dest)  # exclusive new fixture, never overwrite
    m = read_session(dest)[0].metadata
    Image.fromarray(np.zeros((2, 2, 3), dtype=np.uint8)).save(dest / 'synthetic_original_rgb.png')
    image = {'frame_id': m['frame_id'], 'session_id': m['session_id'], 'file': 'synthetic_original_rgb.png',
             'sha256': digest(dest / 'synthetic_original_rgb.png'), 'width': 2, 'height': 2, 'encoding': 'RGB8',
             'image_kind': 'original_rgb', 'time': m['capture_time'], 'pair_status': 'unverified',
             'pair_evidence': None, 'aligned_to_depth': False, 'alignment_method': None,
             'calibration_id': None, 'provenance_kind': 'synthetic'}
    with (dest / 'images.jsonl').open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(image) + '\n')
    with (dest / 'annotations.jsonl').open('x', encoding='utf-8') as stream:
        for purpose, name, version in [('manual_ground_truth', 'manual_mask.npz', 'synthetic-manual-v1'),
                                       ('model_output', 'model_mask.npz', 'synthetic-model-v1')]:
            with (dest / name).open('xb') as mask_stream:
                np.savez_compressed(mask_stream, target_mask=np.ones((2, 2), dtype=bool))
            row = {'schema_version': '1.0.0', 'session_id': m['session_id'], 'frame_id': m['frame_id'],
                   'specimen_id': None, 'mask_file': name, 'mask_key': 'target_mask', 'sha256': digest(dest / name),
                   'width': 2, 'height': 2, 'class_name': 'clay', 'source': 'synthetic depth-coordinate fixture',
                   'version': version, 'purpose': purpose, 'provenance_kind': 'synthetic'}
            stream.write(json.dumps(row) + '\n')
    write_json_new(dest / 'SYNTHETIC_NOTICE.json', {'kind': 'synthetic', 'android_executed': False,
        'real_rgb_collected': False, 'rgb_depth_alignment': 'unverified; same size does not prove alignment',
        'mask_source': 'separately constructed depth-coordinate interface fixture, not derived from RGB',
        'specimen_id': None, 'model_trained': False})
    print(dest)
