"""Create new clearly synthetic intake plus a blocked D405 receipt; never overwrite."""
import copy
import json
from pathlib import Path
import shutil
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from depth_preflight import digest, write_json_new, MISSING


def create_synthetic(base):
    base.mkdir(parents=True, exist_ok=False)
    raw = np.array([[[1000, 1000], [1000, 0]]], dtype=np.uint16)
    with (base / 'source.npz').open('xb') as stream:
        np.savez_compressed(stream, depth_raw=raw)
    m = json.loads((ROOT / 'examples/synthetic/frame_000001/metadata.json').read_text(encoding='utf-8'))
    m['session_id'] = 'ade71_synthetic_file_boundary'
    m['provenance']['raw_file'] = 'raw/source.npz'
    m['provenance']['raw_sha256'] = digest(base / 'source.npz')
    write_json_new(base / 'basis.json', {
        'basis_format': 'ade71-local-intake-v1', 'notice': 'SYNTHETIC ONLY; local intake sidecar, not core schema',
        'source': {'file': 'source.npz', 'sha256': digest(base / 'source.npz'),
                   'key': 'depth_raw', 'dtype': 'uint16', 'shape': [1, 2, 2]},
        'conversion': {'scale_to_m': .001, 'semantics': 'optical_axis_z', 'invalid_values': [0],
                       'raw_65535_policy': 'unconfirmed', 'raw_65535_evidence': None},
        'evidence_files': {}, 'real_geometry': None,
        'frames': [{'source_frame_index': 0, 'metadata': m, 'target': None}]})
    write_json_new(base / 'expected_points.json', [[0, 0, 1], [.01, 0, 1], [0, .01, 1]])
    return base


def create_blocked_d405(base):
    originals = ROOT / 'outputs/ade71_preflight/run_e98d488d4ab945cfae53d459deb80031/originals'
    receipt = json.loads((ROOT / 'docs/inputs/ade71-d405-20261013.json').read_text(encoding='utf-8'))
    base.mkdir(parents=True, exist_ok=False)
    for name, expected in receipt['members'].items():
        if digest(originals / name) != expected:
            raise ValueError(f'preserved original hash mismatch: {name}')
        with (originals / name).open('rb') as src, (base / name).open('xb') as dest:
            shutil.copyfileobj(src, dest)
    missing = copy.deepcopy(MISSING)
    # Timestamps/specimen are nullable in v1; absent values must stay absent.
    for item in missing:
        item['blocks_core_session'] = item['item'] not in (
            'per_frame_capture_and_host_receive_timestamps', 'specimen_id_capture_conditions_three_conditions')
    write_json_new(base / 'basis.json', {
        'basis_format': 'ade71-local-intake-v1', 'notice': 'REAL D405 delivery; NOT a complete conversion basis',
        'source': {**receipt['raw_array'], 'sha256': receipt['members']['depth10.npz']},
        'evidence_files': {name.split('.')[0]: {'file': name, 'sha256': h} for name, h in receipt['members'].items()},
        'blocked_requirements': missing, 'frames': [],
        'conversion': {'scale_to_m': 9.999999747378752e-05, 'semantics': None,
                       'invalid_values': [0], 'raw_65535_policy': 'unconfirmed', 'raw_65535_evidence': None},
        'real_geometry': None})


if __name__ == '__main__':
    base = ROOT / 'examples/ade71_session_intake'
    create_synthetic(base / 'synthetic')
    create_blocked_d405(base / 'd405_blocked')
    print(base)
