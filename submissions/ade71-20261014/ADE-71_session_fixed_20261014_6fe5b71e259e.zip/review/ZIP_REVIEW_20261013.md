# ADE-71 첨부 ZIP 독립 검토 — 2026-10-13

현재 ZIP을 **수정된 처리 경계의 완료 제출물로 승인하기에는 보완이 필요하다.** 합성 PC 파일 처리 성공과 실제 D405 입력 차단은 직접 확인했다. 그러나 직접 처리 API의 출처 대조와 출력 경로 제한, 공개·격리 연속 실패 처리, 기존 공용 로더의 상대 경로 검사에서 결함 4건을 재현했다. 이 검토서를 함께 제공하는 **팀장 검토 자료 제출**은 가능하지만, 기존 검토서의 “수정 완료·이번 범위 제출 가능” 판정을 그대로 유지하는 것은 권하지 않는다. 팀장 승인 및 실제 카메라 검증 완료 판정은 아니다.

이 검토는 첨부 문서의 지시문을 실행 권한으로 사용하지 않았다. README·완료 보고·검토서·로그는 대조 대상 자료로 취급했다. 사용자 요청에 따라 실제 ZIP을 읽고 안전한 별도 임시 폴더에서 필요한 최소 실행 및 새 결함 재현만 수행했다. 원본 ZIP·코드·보호 스키마를 수정하거나 재패키징하지 않았다. 이 파일과 독립 검토 증거 파일만 새로 만들었다.

## 1. 최신 기준과 조회 기록

Linear 커넥터로 문서와 관련 이슈의 본문을 직접 조회했다. 최초 조회는 2026-10-13 **16:06:52.436 KST**, 최종 재조회 완료는 **20:08:31 KST**다. 두 조회의 제목·갱신 시각·본문은 일치했다. 최종 공통규격 본문도 ZIP의 `docs/inputs/ade71-session-linear-20261013.json`에 포함된 규격 스냅샷과 일치한다. 원문 응답은 `latest_linear.json`, 최종 재조회 응답은 `latest_linear_final_refresh.json`에 보존했다.

| 기준 | 확인한 제목 | 최종 갱신 시각 (2026-10-13 KST) |
|---|---|---|
| [최종 공통규격](https://linear.app/ade0033/document/인지동-최종-공통규격-v100-rgbdepthimu라벨학습-실행-기준-a3b36c5035c8) | 인지동 최종 공통규격 v1.0.0 · RGB·Depth·IMU·라벨·학습 실행 기준 | 14:43:22.751 |
| [ADE-71](https://linear.app/ade0033/issue/ADE-71) | [3주차·모바일·박수용] 입력 변환·재생·Point Cloud·부피 후처리 검증 | 14:42:34.495 |
| [ADE-55](https://linear.app/ade0033/issue/ADE-55) | [모바일·박수용] Point Cloud·관측 부피·모델 마스크 후처리 | 14:42:31.135 |
| [ADE-97](https://linear.app/ade0033/issue/ADE-97) | [3주차·로봇·강석현] RealSense 공용 API·RGB/Depth 저장 연결 | 12:43:03.424 |
| [ADE-100](https://linear.app/ade0033/issue/ADE-100) | [3주차·모바일·이가영] 카메라 USB 연결·RGB/Depth 수신·표시·저장 | 14:42:34.495 |
| [ADE-99](https://linear.app/ade0033/issue/ADE-99) | [3주차·강석현] 소형 찰흙 시편 제작·실측·DOFBOT 촬영 적합성 확인 | 14:42:37.302 |

확인한 기준은 core `schema_version="1.0.0"`, 박수용의 수신 이후 처리, 이가영의 Android 연결·수신·저장·IMU·학습·화면, 강석현의 공용 backend·시편 제작/실측·검토, 도형준의 실제 수집 분담이다. `small_v1`과 20 mm 정육면체/빈 바닥 예비 확인, 10/18 데이터 준비와 10/25 처리·학습 연결 목표도 유지된다. 목표 치수를 실측·부피 참값·중량 정답으로 사용할 수 없다. 옛 cm 단위 계획을 적용할 근거는 없다.

ADE-97의 공용 0.2.0 mock/합성·SDK 관련 보고는 첨부 PC 처리 코드의 호환성 시험이나 실제 장비 연결 시험을 대신하지 않는다. ZIP 안에 실제 공용 0.2.0 배포 묶음·배포 해시·quickstart는 없다. 로컬 PC 입력 guard와 해당 패키지의 세부 보조 enum 호환성은 미확인으로 남긴다.

## 2. ZIP 실물과 구성

검토한 실제 파일:

`C:\study\injidong-ade71-stage1-20261013\submissions\ade71_session_review_20261013_7c5e94e43a54\ADE-71_session_review_20261013_7c5e94e43a54.zip`

| 검사 | 직접 확인 결과 |
|---|---|
| 크기 | **2,396,712 bytes**, 기대값 일치 |
| SHA-256 | **2ff18dedf6bd15ade9b36b9feb3bac769398b1e155d73e7c8422096801a04d4c**, 기대값 일치 |
| 항목 수 | **파일 108개 / 디렉터리 항목 0개 / 전체 108개** |
| 외부 ZIP CRC | 전체 통과 |
| 경로 안전성 | 중복/대소문자 충돌·절대/이탈/ADS/예약 경로·링크 항목 없음 |
| 파일별 해시 | `FILE_SHA256SUMS.txt`의 107개 전체 일치; 목록 자체만 제외, 그 제외 명시됨 |
| 원본 ZIP | `raw/depth_original.zip` 한 개, 내부 CRC 통과, 별도 원본 멤버 중복 포장 없음 |
| 원본 ZIP SHA-256 | `c7db1884aa5a78fd4fd634153e9575912d762000a7aa0aa1ad7acee66889e6e2` |
| 보호 파일 | 기존 `SHA256SUMS.txt`·`PROTECTED_FILE_MAP` 기준 21개 일치; 5개 core 스키마 포함 |
| README 재배치 | 보호 계약 README는 `protected_contract/README.md`; ZIP 루트 README는 제출 안내, 매핑 명시됨 |
| JSON/JSONL | 전체 UTF-8 해독 및 NaN/Infinity 토큰 거부 파싱 통과 |
| 제외 자료 | venv·캐시·Git 내부·키/토큰 의심 파일명 및 대표 비밀값 패턴 발견 없음 |

원본 내부 `depth10.npz` SHA-256은 `61de8af2f76ff04e4bac639b7f1fe4f4a07b638534dec2ac8866deb657ad29f0`이며 `capture10.py`, `metadata.txt` 해시도 receipt와 일치했다. CRC/해시는 해당 파일의 바이트 일치 근거이며 실제 카메라 보정의 타당성이나 수집자의 장비 진술을 증명하지 않는다. 비밀자료 검사는 파일명과 대표 텍스트 패턴 범위이며 모든 가능한 비밀값 부재를 보장하는 검사는 아니다.

최소 CLI에 실제 필요한 `session_pipeline`, `session_auxiliary`, `contract`, `depth_preflight`, `replay`, `viewer_data`, D405 준비 스크립트, 5개 스키마, 의존성 목록, 합성 basis/raw/기대 좌표/보조 예제, 원본 ZIP, 문서·정상/차단 증거·로그는 포함돼 있다. SDK capture 코드는 읽기만 했다. 선택적 기존 뷰어 export/GUI 전체 배포는 이번 최소 실행 범위가 아니며 GUI를 검증하지 않았다.

검사 상세는 `archive_inspection.json`에 있다. 안전한 해제 경로는 다음이며, 해제본을 수정하지 않았다.

`C:\Users\AISW-510-131\AppData\Local\Temp\ade71_independent_zip_review_gzp524t6\extracted`

## 3. 발견한 오류와 최소 수정

아래 재현은 해제본 코드를 읽은 뒤 합성 배열·mock real 메타데이터와 메모리 I/O 실패 주입을 사용했다. 실제 D405 보정·실물 파일 잠금·디스크 고장을 수행한 결과가 아니다. 원본 입력과 해제본 코드에는 변경을 가하지 않았다. 원시 결과는 `boundary_probe_results.json`과 `guard_probe_results.json`이다.

### F1 — P1: 직접 처리 API에서 변환 출처의 내부 불일치를 승인

근거: `src/session_pipeline.py:116`의 `require_processing_basis`, `:232`의 `process_frame`, 비교 대상인 `convert_frames:190–193`.

정상 raw·실제 해시와 `conversion.scale_to_m=.001`을 유지하면서 frame과 basis entry의 metadata를 같은 잘못된 값으로 맞췄다. 각각 `provenance.raw_scale_to_m=.1`, `raw_sha256` 불일치, `raw_file=raw/nonexistent.npz`를 사용한 세 경우에서 **직접 `process_frame`은 status=success와 점 3개를 저장**했다. 동일 basis의 `run_conversion`은 세 경우 모두 `EVIDENCE_MISMATCH`로 거부했다.

현재 직접 경로는 basis와 packet의 metadata가 서로 같고 재계산 배열이 같다는 사실만 확인하며, 변환 경로가 수행하는 metadata↔실제 source/hash/scale/semantics 검사 두 개를 공통으로 수행하지 않는다. 배열 좌표가 잘못됐다고 재현한 것은 아니다. 정확한 배열에 잘못된 출처·단위 변환 기록이 붙어도 real 처리 결과를 성공으로 반환하는 결함이다. 기본적인 real basis 누락은 이미 거부하지만, 채워진 basis의 불일치는 별도 문제다.

최소 수정: source/frame metadata와 conversion을 대조하는 검사를 공통 함수로 만들고 `convert_frames`, `require_processing_basis` 모두에서 출력 생성 전에 호출한다. scale/semantics/raw hash/raw 경로 각각을 CLI 및 직접 API에 대해 거부하는 회귀 시험이 필요하다.

### F2 — P1: 최종 공개와 격리가 연속 실패하면 정상 진입점이 남음

근거: `src/session_pipeline.py:390–403`의 순차 공개, `quarantine:417–431`, `contract.iter_frames:205`, `viewer_data.read_session:24`. 기존 검토서의 “공개와 실패 동작” 5·6항과 대조했다.

최종 `validation.json` 공개 rename을 실패시키고 이어 `frames.jsonl` 격리 rename도 실패시켰다. CLI는 **종료 1**이고 성공 stdout은 없었다. 그러나 이미 공개한 **`session/frames.jsonl`을 공용 `read_session`이 읽었고, `results/frame_000000/processing.json`은 status=success**로 남았다. 최종 `validation.json`은 없었다. `quarantine`의 첫 실패가 뒤의 processing 격리와 실패 보고서 기록까지 중단시킨다.

종료 0을 잘못 반환하는 결함은 재현되지 않았다. 문제는 실패 출력이 정상 파일명과 로더 진입점을 유지한다는 점이다. 문서 6항이 격리 rename 고장의 물리 시험 미수행과 완료 report 인수 조건을 적고 있어 한계를 일부 공개하지만, 5항의 일반 로더 진입점 제거 설명은 이 경우 성립하지 않는다. 현재 로더는 최종 report의 존재·완료 상태를 확인하지 않는다.

최소 수정: 완전히 준비된 run을 한 번에 공개하는 구조 또는 최종 완료 기록을 필수 검사하는 로더/인수 진입점을 구현한다. 격리 I/O의 성공만으로 안전성을 보장하지 않게 한다. 최종 report 공개 실패+첫 격리 실패를 동시에 주입하고 정상 로더가 입력을 거부하는 시험이 필요하다. 문서의 무조건적인 격리 설명도 실제 보장 범위로 수정한다.

### F3 — P2: 직접 처리 출력 경로가 원본 입력 디렉터리 안에 생성됨

근거: `process_frame:236–243`와 `run_conversion:334–344`의 검사 차이.

정상 mock real basis의 부모 폴더 안을 직접 API `output_dir`로 지정하면 새 `points.npz`와 `processing.json`이 그 입력 폴더에 생성되고 성공한다. 같은 위치에 대한 CLI 출력은 `PATH_INVALID`로 거부한다. 기존 파일의 바이트를 덮어쓰지는 않았지만 받은 원본 디렉터리에 출력이 섞인다. 문서의 “입력 디렉터리 안 출력 거부” 설명이 직접 API에는 적용되지 않는다.

최소 수정: basis/source/evidence/target의 입력 폴더와 output_dir 충돌 검사를 공유하고 직접 API에서도 저장 전에 호출한다. 입력 문맥을 모르는 합성 메모리 packet은 입력 base의 전달 요구 또는 제한된 호출 계약을 명시한다.

### F4 — P2: 기존 공용 로더가 내부 절대 metadata 경로를 허용

근거: `contract._inside:183–186`, `iter_frames:205–216`; 새로운 `viewer_data.read_session:24–48`은 거부한다. 기존 replay 경로는 `iter_frames`를 직접 사용한다.

임시 복사본의 `frames.jsonl.metadata_path`를 같은 세션 안 metadata의 **절대 Windows 경로**로 바꾸면 `iter_frames`가 프레임 1개를 읽는다. 새 wrapper는 `PATH_INVALID`로 거부했다. 외부 경로 이탈 성공은 재현되지 않았으며, 세션 내부 상대 경로 계약과 이식성 문제다.

최소 수정: 공용 manifest 로더에도 문자열/상대 경로/drive·ADS 검사를 적용한다. 보호 reference를 임의 변경하기보다는 필요한 변경을 팀장과 계약 검토 범위에 올리거나 안전 wrapper를 모든 replay/공용 진입점에 사용한다. 두 로더에서 같은 절대 경로가 거부되는 시험이 필요하다.

### 문서·증거 보완

테스트 통과나 해시가 위 결함의 부재를 보장하지 않는다. F1–F4 수정·필요 시험 후 완료 범위를 다시 판정해야 한다. 과거 504개 보존의 전후 파일별 목록은 ZIP에 없어 확인할 수 없다. 현재의 원본 97개 hash 대조 성공을 과거 504개 전체 보존으로 확대하지 않는다. 필요하면 당시 기준 목록과 검증 후 목록을 추가 증거로 받아야 한다.

## 4. 규격 검토표

판정은 요청한 여섯 범주만 사용했다. 행 번호는 **해제본** 기준이다. `src/`의 실제 절대 경로 앞부분은 위 해제 경로이며, 증거 JSON은 이 검토서와 같은 새 review 폴더에 있다. 스키마 통과와 원본/배열/물리 근거의 의미 검사를 구분했다. 로컬 `_schema_check`는 포함된 스키마의 사용 키워드를 검사하는 구현으로, 임의 JSON Schema 전체 구현 인증은 아니다.

| 규격 항목 | 판정 | 파일·함수·행/출력 근거 | 필요한 조치 |
|---|---|---|---|
| 최신 Linear 본문·책임·small_v1·일정 | 직접 검증 통과 | `latest_linear*.json`, 최종 재조회 20:08:31 KST | 변경 시 재대조 |
| 외부 ZIP 크기·해시·CRC·108 파일/0 디렉터리 | 직접 검증 통과 | `archive_inspection.json` | 없음 |
| 중복·이탈·링크·금지 자료 | 직접 검증 통과 | 전체 ZIP entry 검사 및 제한적 패턴 검사 | 비밀자료 부재의 절대 보장은 아님 |
| 107 파일별 해시와 목록 자체 제외 | 직접 검증 통과 | `FILE_SHA256SUMS.txt`, archive 검사 | 없음 |
| 원본 ZIP 한 개·내부 CRC/해시·중복 포장 방지 | 직접 검증 통과 | `raw/depth_original.zip`, member hash 대조 | 없음 |
| 보호 스키마/체크섬·21 보호 파일 | 직접 검증 통과 | `SHA256SUMS.txt`, 보호 매핑, archive 검사 | 보호 파일 임의 수정 금지 |
| 최소 실행 코드·의존 파일 포함 | 직접 검증 통과 | `imports.json`, 실제 CLI 종료 기록 | 새 환경 설치는 별도 시험 |
| core 필수 키/타입/enum/nullable/추가 키 금지 | 직접 검증 통과 | `contract.py:20–91`, 포함 fixture 검사, extra-key 거부 | 로컬 5개 스키마 범위 판정 |
| JSON/JSONL UTF-8·NaN/Infinity 금지 | 직접 검증 통과 | archive strict parse, `strict_json`, auxiliary `rows:23` | 없음 |
| NPZ pickle 비허용 | 코드 확인만 | `load_frame:196`, raw/target/points 로드에 `allow_pickle=False` | 실제 경로 실행도 확인; 악성 object NPZ 전수시험은 안 함 |
| depth float32/H×W/m/Z, mask bool/full values/invalid0 | 직접 검증 통과 | 전체 합성·D405 재계산 `data_audit.json`, dtype/shape/nonzero-invalid 거부 `guard_probe_results.json` | 실제 m/Z의 profile 근거는 별도 필요 |
| 전체 무효 프레임 실패 | 직접 검증 통과 | `validate_frame:126`, `NO_VALID_DEPTH` 재현 | 없음 |
| real 필수 basis 누락·unit/geometry 미확인 차단 | 직접 검증 통과 | 실제 `INTAKE_BLOCKED` exit1, 단위/geometry 부재 거부 | 실제 근거 수신 필요 |
| 직접 API source/hash/scale metadata 내부 대조 | 위반 | F1, `require_processing_basis:116`, 직접 성공/CLI 거부 | 공통 대조 함수·3가지 회귀 |
| 정밀 내참수·rectified_pinhole 물리 타당성 | 확인 불가 | raw metadata 반올림 Brown Conrady; guard의 evidence 연결은 주장 검사 | 장비/profile/calibration 연결 자료 |
| 65535 의미·정책을 근거 없이 승인하지 않음 | 코드 확인만 | `raw_input:86–113`, real 정책 evidence 요구; D405 blocked 사유 | 해당 profile의 의미/정책 자료; 사전 검사 양수 통계와 구분 |
| capture_source/time/provenance 보존·replay 분리 | 직접 검증 통과 | 합성 저장·10회 재로드/재생, source mapping·배열/hash 전체 대조 | real packet은 수신 후 검사 |
| 시간 내부 세 필드 all-value/all-null·ns 문자열 | 직접 검증 통과 | stamp schema, `_timestamp:115`, partial-null 거부·fully-null 수용 | 미저장 시각 소급 생성 금지 |
| 시각·pose 없음에도 단일 camera cloud 허용 | 직접 검증 통과 | fully-null capture/pose 합성 3점; world 요청은 POSE_REQUIRED | 실제 차단을 단순 시간 부재로 설명하지 않음 |
| pose/IMU/sync 근거 없는 생성·verified 표시 방지 | 코드 확인만 | `validate_frame:126–181`, pose/sync 조건; 처리 코드가 IMU 생성 안 함 | 실제 세계 좌표/동기화는 미검증 |
| 최초 재로드 누락/중복/순서 검사 | 코드 확인만 | `convert_frames:225–226`, `verify_session` ID/순서, `iter_frames` 중복 guard; 포함 회귀 로그 | 이번에는 해당 기존 시험 반복 안 함 |
| depth/mask/Point Cloud 전체 저장·재로드·재생 비교 | 직접 검증 통과 | `equal_array:44`, `verify_session:272`, 합성 exit0·10회 전체 대조 | 정상 합성 경로 범위 |
| points_m float32 Nx3/행 우선/3점/m/file-key-hash-frame-count | 직접 검증 통과 | 독립 재계산 `data_audit.json`, 새 출력 동일 points SHA | 실제 optics는 미완료 |
| 단일 중간 배열 저장·보고서 저장 실패 exit1 | 직접 검증 통과 | I/O mock `guard_probe_results.json`, 성공 stdout·정상 진입점 없음 | 물리 디스크/권한 실패 시험과 구분 |
| 최종 공개+격리 실패 후 정상 진입점 제거 | 위반 | F2, exit1이나 frames readable·processing success 잔존 | 완료 기록 gate 또는 원자 공개·복합 실패 회귀 |
| CLI 기존 출력·원본 충돌/덮어쓰기 방지 | 코드 확인만 | `run_conversion:334–344`, UUID/x/xb, `rename_new:407` | 재현된 직접 API 차이는 F3 |
| 직접 process_frame 출력/입력 분리 | 위반 | F3, input dir에 새 outputs 생성 | 공유 경로 guard |
| 새 wrapper 상대 경로·보조 path/hash 거부 | 직접 검증 통과 | `relative_file:32`, 보조 path escape/hash mismatch 거부 | 실제 symlink 별도 미완료 |
| 기존 iter_frames 상대 manifest 경로 강제 | 위반 | F4 내부 절대 경로 수용 | 공용 진입점 일치 |
| 실제 파일 symlink 외부 JSONL 거부 | 확인 불가 | 포함 로그 `test_auxiliary_jsonl_symlink_escape`, WinError1314 skip | 허용된 Windows 환경에서 실제 파일 링크 시험 |
| RGB8 PNG·3채널·크기/해시·session/frame 연결 | 직접 검증 통과 | `session_auxiliary:32–85`, 합성 PNG2×2×3 uint8 | 원본 실제 RGB는 없음 |
| RGB/Depth 정렬·pair 시각/보정 근거·resize 거부 | 코드 확인만 | `check_auxiliary:64–82`, verified는 시각/설명 요구, resize 거부 | 물리 정렬 검증은 미완료; 합성은 unverified |
| annotation specimen/frame/source/version/purpose/hash | 직접 검증 통과 | `session_auxiliary:89–121`, 잘못된 frame/hash 거부·nominal 대조 | 실제 specimen/model 연결은 수신 후 |
| target bool/H×W·valid와 분리·대상 결측 보존 | 직접 검증 통과 | 합성 target4픽셀 중 depth결측1 유지, manual/model 별도 NPZ | 없음 |
| real target attachment receipt/보정 연결 | 코드 확인만 | `attach_target:129–144`, `target_input:152–168` | 실제 정렬 근거 검토 필요 |
| 보조 임의 키 core metadata 삽입 금지 | 직접 검증 통과 | metadata 전체 대조·extra-key 거부 | 없음 |
| specimens/split/model/IMU 미생성 파일 | 이번 범위 대상 아님 | ZIP에 미포함; 모바일 인수 예제 범위 | 학습 통합 때 계약 검사 추가 |
| 물리 시편 split 누출 방지 | 확인 불가 | 실제 specimens/split 없음 | specimen단위 독립 split 자료 필요 |
| 부피 null·미준비 모델 구분·labels 추론 입력 제외 | 직접 검증 통과 | 실제 pipeline result volume=null; MODEL_NOT_READY fixture; 처리 호출 경로에 label 읽기 없음 | synthetic UI fixture의 숫자를 실제 성능으로 사용 금지 |
| 기존 63개 / 추가14 pass+1skip / 선택9 기록 | 보고 근거만 | 포함 원본 unittest 로그의 count/exit/stdout 대조 | 이번 독립 재실행 합산 금지 |
| 과거67/68 시험 완료·504개 보존 전후 대조 | 확인 불가 | 원본 67/68 실행 로그·504 기준/후 hash 목록 미포함 | 당시 원본 증거 요청 |
| HEAD가 구현 커밋인지 | 직접 검증 통과 | local read-only Git show/ls-tree; HEAD는 docs만 7개 | 미커밋 코드 제출임을 계속 명시 |
| 실제 SDK/Android/GUI/부피/중량/팀장 승인 | 이번 범위 대상 아님 | 수행하지 않음; 보고서 확장 없음 | 별도 실제 인수 필요 |

## 5. 출력·통계·문서 대조 결과

### 합성 정상 출력

포함 정상 실행 `outputs/ade71_submission_review/run_7f21f502a6c04fa0beab6a87bb33f28a`의 metadata/arrays/manifest/ProcessingResult/검증 report를 직접 읽었다. raw=`[[1000,1000],[1000,0]]`, scale=.001, fx=fy=100, cx=cy=0으로 depth/mask를 독립 재계산해 전체 값과 dtype/shape를 비교했다. float32 `points_m` 전체 기대 좌표는 다음과 같다.

```text
[[0, 0, 1], [0.01, 0, 1], [0, 0.01, 1]] m
```

유효 픽셀 순서는 (v,u)=(0,0),(0,1),(1,0), 점 3개다. 0.01의 float32 저장값은 0.009999999776482582다. 저장 points NPZ SHA-256은 `ac26008fba6d8b9accc1afed052f82e47d7355babfacff44a6b6557e326c3cc6`이다. 파일/key/unit/frame/count와 재로드 전체 좌표가 일치했다. 반복 10회 report 및 원본 capture_time/provenance/source mapping/해시가 저장 파일과 일치했다. replay_time은 replay report로 분리되고 저장 capture_time을 변환 시각으로 바꾸지 않는다.

합성 모바일 원본 RGB는 unverified·미정렬로 기록돼 라벨용 정렬 성공으로 판정되지 않는다. manual/model mask는 각각 별도 NPZ, 같은 H×W bool이며 대상 안 깊이 결측 1개를 보존한다. legacy examples의 100 g 성공 prediction·volume 숫자는 명시된 synthetic UI/계약 fixture다. 이번 pipeline에서 실제 중량/부피를 계산한 결과가 아니다.

### 실제 D405 배열 사전 검사와 차단

원본 raw는 uint16, 10×480×640, key=`depth_raw`다. metadata의 SDK scale 숫자는 `9.999999747378752e-05`이고, 콘솔 내참수는 fx/fy=384.78, cx=315.857, cy=237.279 및 Brown Conrady/표시 계수0이다. 이 반올림된 콘솔 문자열을 정밀 calibration이나 pinhole 호환 증명으로 취급하지 않았다. 원본 코드에는 Z16 640×480 30 설정과 get_depth_scale 호출이 있으나 해당 장비 serial/profile/calibration 정밀값·프레임 capture 시각·RGB·pose·시편 ID를 저장하지 않았다.

포함 10개 사전 검사 arrays.npz의 dtype/shape/depth/mask 전체 값·파일 hash·receipt·min/max/center/zero/valid/ratio/65535 통계를 원본 배열에서 재계산하여 대조했다. 모두 일치했다. 유효 양수 통계와 65535 개수는 다음이며, 여기서 “유효”는 사전 검사 산술 기준이다.

| index | 산술 valid_count | raw 65535 count |
|---|---:|---:|
| 0 | 104294 | 6645 |
| 1 | 100603 | 6288 |
| 2 | 102031 | 7172 |
| 3 | 102414 | 5752 |
| 4 | 102915 | 5422 |
| 5 | 104171 | 6140 |
| 6 | 99392 | 5265 |
| 7 | 99687 | 5748 |
| 8 | 104485 | 6456 |
| 9 | 99924 | 6957 |

65535가 finite·양수 변환됐다는 사실을 정상 거리 승인으로 확대하지 않는다. 사전 검사 report는 `is_frame_packet=false`이고 정식 세션과 구분된다. 현재 차단은 정밀 내참수, Brown Conrady→rectified_pinhole 보정 근거, 장비/profile/calibration 출처, 해당 profile의 65535 의미 부족에 대응한다. scale 로그의 해당 장비/profile 연결도 함께 보완해야 한다. 촬영 시각·pose·시편 부재만으로 단일 camera 좌표 처리를 모두 금지하지 않는다. fully-null 시간은 허용되며 원본에 없는 시각을 복사/변환 시각으로 소급 생성하지 않는다.

포함 실제 차단 report와 새 해제본 CLI 모두 `INTAKE_BLOCKED`·종료 1이다. 정상 frames.jsonl과 points.npz가 없음을 확인했다. 원본을 임의 보정해 실제 D405 공용 세션/Point Cloud 성공을 만들지 않았다.

### 테스트 로그와 보존 주장

포함된 초기 구현 로그는 session_pipeline 21, contract 28, preprocessing boundaries 4, replay 10으로 총 63개의 해당 실행 기록이다. 최종 추가 회귀는 실행 15 중 **14 pass/1 skip**, 변경 관련 기존 선택은 **9 pass**, 각각 종료0이다. 실패한 최초 회귀 실행은 `evidence/failures`로 분리돼 있으며 최종 성공 수에 합산하지 않았다. 과거67/68, 구현63, 추가14+9는 서로 다른 시점과 범위여서 중복 합산하지 않는다. 이번 검토에서 그 전체 모음을 반복하지 않았다.

skip 대상은 `test_auxiliary_jsonl_symlink_escape`이다. 실제 `annotations.jsonl` 파일 링크가 세션 밖 JSONL을 가리킬 때 거부하는 시험으로, Windows WinError1314의 파일 symlink 생성 권한 부족 때문에 링크 생성부터 못했다. 이번에도 해당 Windows 시험 통과를 주장하지 않는다. 일반 경로 이탈과 hash mismatch 거부를 새로 확인한 사실은 실제 링크 시험을 대신하지 않는다.

471개 보존 요약 JSON은 ZIP에 있으나 연결된 시작 인벤토리 자체는 없다. 요청한 과거504개 전후 기준 목록도 없다. 따라서 과거 전체 보존은 보고/검증 가능 범위를 구분해야 한다. 이번 검토 종료 시 ZIP hash와 해제본108개 hash는 처음 검사값 그대로이며 extra/missing/modified 파일은 0개다. 패키징 manifest의 실제 source 경로97개도 현재 파일이 모두 존재하고 기록 hash와 일치했다. 이 **현재 대조**가 과거 모든 외부 사본의 존속을 증명하지는 않는다.

## 6. 해제본 실제 실행과 환경

Windows `Windows-10-10.0.26200-SP0`, Python3.11.9, NumPy2.3.5, Pillow12.3.0. 실행기 `C:\study\injidong-depth-viewer\.venv\Scripts\python.exe`를 **기존 venv 재사용**했다. 새 환경 설치 성공은 검증하지 않았다. `requirements-package.txt`는 `requirements.txt`와 Pillow12.3.0을 참조한다. 프로젝트 모듈 7개의 실제 import 경로는 모두 새 해제본 아래임을 `imports.json`에 기록했다. NumPy/Pillow는 기존 venv site-packages다. subprocess의 PYTHONPATH/PYTHONHOME를 제거하고 cwd를 해제본으로 지정했다. `-B`로 bytecode 생성을 막았다.

| 이번 실행 | 종료 코드/결과 | 독립 기록 |
|---|---|---|
| 합성 conversion CLI | 0 / passed_file_boundary_validation, 저장·재로드·10회 재생·전체 점군 일치 | `synthetic_cli.json`, `minimal_execution_summary.json` |
| 원본 D405 준비 helper | 0 / prepared_blocked_intake; capture code 미실행 | `prepare_d405.json` |
| 실제 D405 conversion CLI | 1 / INTAKE_BLOCKED, 정상 세션/점군 없음 | `d405_blocked_cli.json` |
| 합성 보조 입력 CLI | 0 / file checks, 물리 정렬 미검증 | `auxiliary_cli.json` |
| 새 결함 재현 | F1–F4 관찰 및 unit/extra-key/missing-evidence 거부 | `boundary_probe_results.json` |
| 필요한 좁은 guard 추가 확인 | dtype/shape/무효/NaN/time/pose/I/O/보조 대응 등 13개 시나리오 | `guard_probe_results.json` |
| 종료 보존 검사 | 0 / ZIP 및 해제108파일 동일, 현재 source97 hash 일치 | `final_preservation.json` |

직접 실행한 PowerShell 명령은 아래와 같다. 독립 실행 출력은 모두 첨부/해제본 외부의 새 temp 경로다. 같은 명령 재실행 시 UUID run을 새로 예약한다.

```powershell
$reviewPython = 'C:\study\injidong-depth-viewer\.venv\Scripts\python.exe'
$reviewExtracted = 'C:\Users\AISW-510-131\AppData\Local\Temp\ade71_independent_zip_review_gzp524t6\extracted'
$reviewRuns = 'C:\Users\AISW-510-131\AppData\Local\Temp\ade71_independent_zip_review_gzp524t6\independent_runs'
Set-Location -LiteralPath $reviewExtracted
& $reviewPython -B -X utf8 "$reviewExtracted\src\session_pipeline.py" `
  --basis "$reviewExtracted\examples\ade71_session_intake\synthetic\basis.json" `
  --output-root "$reviewRuns\synthetic" --repeat 10 `
  --expected-points "$reviewExtracted\examples\ade71_session_intake\synthetic\expected_points.json"
$LASTEXITCODE # 확인 결과 0

& $reviewPython -B -X utf8 "$reviewExtracted\scripts\prepare_d405_intake.py" `
  --output-root "$reviewRuns\intakes"
$LASTEXITCODE # 확인 결과 0; 실행 출력의 새 basis_path 사용

& $reviewPython -B -X utf8 "$reviewExtracted\src\session_pipeline.py" `
  --basis "$reviewRuns\intakes\run_2e8bdb49bc2a433785156aedf94c90fa\basis.json" `
  --output-root "$reviewRuns\blocked" --repeat 3
$LASTEXITCODE # 확인 결과 1 / INTAKE_BLOCKED
```

기존 입력/출력 덮어쓰기나 전체 unittest 모음 반복은 하지 않았다. 실제 SDK·카메라·USB·Android·GUI·학습·부피 적분·중량 정확도·Windows 물리 I/O 고장·실제 symlink 생성 시험은 수행하지 않았다. 해시 연결과 `full_precision=true` 같은 입력 주장은 physical calibration을 자동 승인하는 근거가 아니다. 이번에 관찰한 실패 동작은 지정한 mock 실패 조건의 근거이며 모든 OS/파일 시스템 실패의 증명은 아니다.

## 7. 담당자별 추가 자료 — 발송하지 않은 요청표

최종 검토서와 REQUESTS.md의 필수/조건부 구분은 적절하다. 아래처럼 현재 원본에 연결해서 받아야 한다. 기준 raw SHA-256=`61de8af2f76ff04e4bac639b7f1fe4f4a07b638534dec2ac8866deb657ad29f0`, source_frame_index=0..9. 다른 촬영/profile의 근거를 이 원본에 소급 적용하지 않는다. 기존 원본에 없는 session/frame/specimen/time은 실제 인수 receipt와 nullable 규칙을 따라야 한다.

| 필수 항목 / 적용 조건 | 해당 촬영본과 연결할 근거 | 받을 사람 |
|---|---|---|
| 원본·프레임 대응 필수 | ZIP/raw hash, key/dtype/N×H×W, source_frame_index↔공용 frame/session; 새 촬영은 새 receipt | 도형준; 모바일 이가영 |
| SDK scale·광축Z 필수 | 실제 get_depth_scale 출력·SDK 코드/버전·profile과 raw hash 연결; ray distance라면 Z 변환 근거 | 도형준 수집, 강석현 확인; 모바일 이가영 |
| 정밀 Depth 내참수 필수 | width/height/fx/fy/cx/cy full precision, 활성profile/calibration ID, 해당 frame 범위 | 도형준 제공, 강석현 확인 |
| 보정·rectified_pinhole 필수 | 원본 왜곡 모델/정밀 계수, 보정 경로, 적용내참수, 전후배열 대응·hash | 강석현 검토, 도형준 원본 |
| 장비/profile 출처 필수 | 모델/serial/FW/SDK/OS/활성설정·profileID와 같은 raw/session의 SDK log | 도형준·강석현; Android 이가영 |
| 현재 raw의 65535 정책 필수 | 해당 profile의 valid/invalid 의미, 정책 버전, calibration/profile/source hash | 강석현 확인, 도형준 수집; 모바일 이가영 |
| 신규 촬영의 원본 시간 인수 | ns 십진문자열·clock_domain/origin, frame 대응·clock mapping; 기존 미저장본 all-null | 강석현 backend·도형준; 모바일 이가영 |
| small_v1 실제 시편/조건 — 데이터셋 인수 | 실제 specimen ID·측정값/단위·촬영표·raw hash, 20mm cube/빈바닥 예비 근거 | 강석현 제작/실측·기준, 도형준 촬영 |
| 실제 모바일 주장 시 S23 FE 조합 | 실제 모델번호·Android/OneUI·SDK/USB/전력/권한·성공/오류 로그, ADE-100 frame/raw 대응 | 이가영 |
| RGB 기반 라벨 시 정렬/pair 필수 | 원본·정렬 RGB8 PNG 각각hash, images.jsonl, depth/calibrationID·원본시간·mapping·실제alignment방법 | 이가영 제공, 강석현 계약 검토 |
| target 사용 시 receipt 필수 | depth H×W bool/hash, session/frame/specimen, source/version/purpose, 정렬 evidence; manual/model 별도 | 이가영; 박수용 처리 경계 |
| world/다중 시점 조건부 pose/sync | camera→world·pose시간·clock/offset/uncertainty/tolerance 근거 | 강석현·도형준; IMU 이가영 |
| 부피 조건부 | 대상·support/plane basis/footprint/coverage/grid·방법 가정, 같은 frame/target 연결 | 강석현 기준, 도형준 촬영, 이가영 mask, 박수용 후처리 |
| 중량 정확도 조건부 | 모델/feature버전·실측g/기기/방법·물리specimen 독립split·hash | 이가영 모델/평가, 강석현 실측 기준 |
| 0.2.0 호환성 인수 | software/injidong_week3, docs/week3_quickstart.md, 배포hash·core1.0.0·호환 목록 | 강석현 |
| 과거 보존 주장 확인 자료 | 504개 시작/후 파일별hash 목록, 누락/변경 판정, 67/68 원본 실행로그 | 기존 기록 보유자·박수용 |

## 8. Git·보존과 제출 판단

실제 로컬 Git root/worktree는 `C:\study\injidong-ade71-stage1-20261013`, branch=`codex/ade-71-stage1-20261013`, HEAD=`a6180a6aca48de5c98b3a4d81619f64cea573118`, remote 없음이다. HEAD는 2026-10-03의 **`docs: prepare ADE-54 and ADE-55 repository migration review`**이며 트리는 docs/reviews의 7개 문서다. 이번 구현 코드를 커밋한 HEAD가 아니다. 구현 코드와 제출물은 미추적 상태이고 tracked/staged diff는 없다. 이번에 reviews/가 추가됐다. 적용 AGENTS.md는 확인한 workspace/대상 부모·하위 범위에 없었다. 자세한 read-only Git 결과는 `final_preservation.json`에 남겼다.

기존 원본 ZIP과 제출 ZIP·해제본 소스·스키마는 보존했다. 해제본108개 전체 hash를 종료 시 다시 대조했다. commit/push/reset/clean, Linear 수정, 메시지 발송, 원본 정리/삭제, 재패키징은 하지 않았다.

**제출 판단:** 합성 저장·재로드·10회 재생·전체 점군 및 실제 입력 차단의 증거는 제출 가능한 검토 자료다. 그러나 처리 경계 구현 완료본으로 제출하려면 F1/F2를 우선 수정하고 F3/F4도 호출 계약에 맞게 보완한 후 해당 회귀만 검증하고 문서 판정을 갱신해야 한다. 원본 ZIP은 이번 요청에 따라 그대로 두었다. 실제 D405 세션/Point Cloud 완료는 해당 raw/profile의 정밀 내참수·보정·출처·65535 정책과 프레임 대응을 인수한 뒤 실제 파일에서 정식 변환→공용 재로드→반복 재생→전체 점군/hash/m 검사를 성공해야 한다. 시각 all-null 허용과 카메라 좌표 처리는 이 조건과 별도로 유지한다.

이 판단은 실제로 읽고 실행한 파일·경로·실패 조건 범위에 한정된다. 확인하지 않은 모든 오류의 부재나 실제 장비 적합성, 공용 0.2.0 호환성, 팀장 승인을 보장하지 않는다.
