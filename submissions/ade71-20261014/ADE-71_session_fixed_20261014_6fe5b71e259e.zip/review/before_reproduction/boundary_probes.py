"""New targeted review probes, only temporary fixture files and in-memory fault injection."""
import copy
from contextlib import redirect_stdout, redirect_stderr
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
from unittest.mock import patch

import numpy as np

HERE=Path(__file__).resolve().parent
info=json.loads((HERE/'archive_inspection.json').read_text(encoding='utf-8'))
ROOT=Path(info['extracted']);TEMP=Path(info['temporary_root'])/'boundary_probes'
TEMP.mkdir(exist_ok=False)
sys.path[:0]=[str(ROOT/'src')]
import contract
import session_pipeline as pipeline
from viewer_data import read_session

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False)
def fixture(name,real=False):
    base=TEMP/name;base.mkdir()
    shutil.copyfile(ROOT/'examples/ade71_session_intake/synthetic/source.npz',base/'source.npz')
    basis=json.loads((ROOT/'examples/ade71_session_intake/synthetic/basis.json').read_text(encoding='utf-8'))
    m=basis['frames'][0]['metadata']
    if real:
        m['capture_source']='pc_camera'
        m['provenance'].update(kind='real',camera={'vendor':'REVIEW_FIXTURE_ONLY','model':'MOCK','serial':None,
            'firmware':None,'sdk':'NOT_ACTUAL_SDK','depth_profile_id':'review-mock-profile'},synthetic_seed=None,synthetic_config=None)
        evidence=base/'evidence.txt';evidence.write_text('Temporary review fixture; NOT actual SDK/calibration evidence',encoding='utf-8')
        basis['evidence_files']={'mock':{'file':'evidence.txt','sha256':sha(evidence)}}
        claims={key:'mock' for key in ('scale','semantics','intrinsics','rectification','device_profile')}
        claims.update(intrinsics_precision='full_precision',calibration_id=m['intrinsics']['calibration_id'],
                      depth_profile_id='review-mock-profile',source_sha256=basis['source']['sha256'])
        basis['real_geometry']=claims
    with np.load(base/'source.npz',allow_pickle=False) as arrays:
        depth,valid=contract.normalize_depth(arrays['depth_raw'][0],.001)
    return base,basis,contract.FramePacket(copy.deepcopy(m),depth,valid)

def main():
    results=[]
    # Control, using explicit mock declarations. No real D405 optical claims.
    base,basis,frame=fixture('control_mock_real',True);write(base/'basis.json',basis)
    control=pipeline.process_frame(frame,{'basis_path':base/'basis.json','output_dir':TEMP/'control_points'})
    results.append({'case':'mock-real control','result':control['status'],'notice':'SYNTHETIC arrays with mock real metadata; no physical calibration verified'})
    for key,bad in [('raw_scale_to_m',.1),('raw_sha256','1'*64),('raw_file','raw/nonexistent.npz')]:
        base,basis,frame=fixture('direct_'+key,True)
        basis['frames'][0]['metadata']['provenance'][key]=bad
        frame.metadata['provenance'][key]=bad
        write(base/'basis.json',basis)
        result=pipeline.process_frame(frame,{'basis_path':base/'basis.json','output_dir':TEMP/('accepted_'+key)})
        run,cli_report=pipeline.run_conversion(base/'basis.json',TEMP/('conversion_'+key),1)
        assert result['status']=='success' and cli_report['status']=='failure'
        results.append({'case':'direct processing inconsistent '+key,'direct_status':result['status'],
                        'point_count':result['point_cloud']['point_count'],'conversion_status':cli_report['status'],
                        'conversion_errors':cli_report['errors'],'points_written':str(TEMP/('accepted_'+key)/'points.npz'),
                        'notice':'mock-only fixture; shows direct API/CLI validation mismatch'})
    base,basis,frame=fixture('direct_input_output_collision',True);write(base/'basis.json',basis)
    before={p.name:sha(p) for p in base.iterdir() if p.is_file()}
    result=pipeline.process_frame(frame,{'basis_path':base/'basis.json','output_dir':base/'new_result_inside_intake'})
    assert result['status']=='success' and (base/'new_result_inside_intake/processing.json').exists()
    try:
        pipeline.run_conversion(base/'basis.json',base/'cli_output',1)
    except contract.ContractError as error:cli_code=error.code
    else:raise AssertionError('CLI collision not rejected')
    results.append({'case':'direct output inside intake','direct_status':result['status'],'cli_code':cli_code,
                    'added_inside_original_directory':True,'existing_input_files_unchanged':all(sha(base/p)==h for p,h in before.items())})
    base,basis,frame=fixture('quarantine_double_fault');write(base/'basis.json',basis)
    original=pipeline.rename_new
    def fail_publication_and_quarantine(source,destination,run):
        if destination.name=='validation.json':raise OSError('review injected final report publication failure')
        if source.name=='frames.jsonl':raise OSError('review injected manifest quarantine rename failure')
        return original(source,destination,run)
    stdout,stderr=io.StringIO(),io.StringIO()
    with patch.object(pipeline,'rename_new',side_effect=fail_publication_and_quarantine),redirect_stdout(stdout),redirect_stderr(stderr):
        code=pipeline.main(['--basis',str(base/'basis.json'),'--output-root',str(TEMP/'double_fault_output'),'--repeat','1'])
    run,=list((TEMP/'double_fault_output').glob('run_*'))
    readable=bool(read_session(run/'session'))
    processing=json.loads((run/'results/frame_000000/processing.json').read_text(encoding='utf-8'))
    assert code==1 and readable and processing['status']=='success'
    results.append({'case':'final report publication + quarantine failure','exit_code':code,
                    'stdout':stdout.getvalue(),'stderr':stderr.getvalue(),'canonical_session_still_readable':readable,
                    'canonical_processing_status':processing['status'],'final_validation_exists':(run/'validation.json').exists(),
                    'run':str(run),'notice':'in-memory I/O fault injection, NOT physical filesystem failure'})
    # Included legacy loader permits absolute in-session metadata paths; wrapper rejects them.
    session=TEMP/'legacy_absolute_manifest';shutil.copytree(ROOT/'examples/synthetic',session)
    row=json.loads((session/'frames.jsonl').read_text(encoding='utf-8'))
    row['metadata_path']=str((session/row['metadata_path']).resolve())
    (session/'frames.jsonl').write_text(json.dumps(row)+'\n',encoding='utf-8')
    frames=list(contract.iter_frames(session))
    try:read_session(session)
    except contract.ContractError as error:wrapper_code=error.code
    else:raise AssertionError('read_session accepted absolute path')
    assert len(frames)==1
    results.append({'case':'legacy iter_frames absolute internal metadata path','accepted_frame_count':len(frames),
                    'wrapper_error':wrapper_code,'metadata_path':row['metadata_path']})
    # Positive guards without running entire inherited test suite.
    blocked=[]
    for name,change in [('scale_unknown',lambda b:b['conversion'].update(scale_to_m=None)),
                         ('metadata_extra_key',lambda b:b['frames'][0]['metadata'].update(unapproved_key=True)),
                         ('real_missing_evidence',lambda b:b.update(real_geometry=None))]:
        base,basis,frame=fixture('guard_'+name,real=(name=='real_missing_evidence'));change(basis);write(base/'basis.json',basis)
        run,r=pipeline.run_conversion(base/'basis.json',TEMP/('guard_output_'+name),1)
        assert r['status']=='failure' and not list(run.rglob('frames.jsonl')) and not list(run.rglob('points.npz'))
        blocked.append({'case':name,'status':r['status'],'errors':r['errors'],'normal_entrypoints':[]})
    write(HERE/'boundary_probe_results.json',{'results':results,'positive_guard_checks':blocked,
            'scope':'new narrow probes against unmodified extracted code; no SDK/camera/network/full suites',
            'local_module':pipeline.__file__})
    print(json.dumps({'cases':len(results),'positive_guards':len(blocked),'findings':results[1:]},ensure_ascii=False))

if __name__=='__main__':main()
