> 2026-10-14 정정: 10/13 ZIP 독립 검토의 추가 결함4건을 수정했습니다. 현재 판정·시험·보호 사본 영향·과거504개 미확인은 [10/14 수정서](ADE-71-zip-fixes-20261014.md)를 따릅니다. 아래는 당시 기록이며 현재 완료 판정으로 단독 사용하지 않습니다.

# ADE-71 공용 세션·Point Cloud 파일 경계 구현 및 실행 결과

**제출 전 최종 검토 반영:** [수정·검증·자료 요청표](ADE-71-session-final-review-20261013.md). 아래 63개 테스트와 원래 출력 링크는 최초 구현 이력이다. 최종 검토에서는 부분 출력 공개·직접 real 처리의 근거 우회·target 대응·보조 경계를 수정했고, 추가 회귀 14개 통과/1개 환경상 skip 및 관련 기존 9개 통과를 별도 기록했다. 기존 전체 테스트를 다시 통과한 것으로 해석하지 않는다. 최신 [합성 성공 출력](../outputs/ade71_submission_review/run_7f21f502a6c04fa0beab6a87bb33f28a/validation.json)은 10회 재생·전체 값 검증과 최종 공개 절차를 통과했고, 최신 [실제 차단 출력](../outputs/ade71_submission_review/run_67b6abc96566486ebbed38ad401c966e/validation.json)은 종료 1이며 세션·점군이 없다.

2026-10-13, Asia/Seoul. 이번 구현은 수신 이후 PC 파일 처리다. 합성 세션 저장·공용 로더 재로드·10회 재생·전체 Point Cloud 저장 검증을 완료했다. 실제 D405는 10프레임 배열 사전 검사만 통과했으며 정식 변환은 `INTAKE_BLOCKED`, 종료 1이다. 팀장 승인·실제 기기 연결·부피·중량 정확도를 뜻하지 않는다.

## 1. 최신 기준과 작업 위치

Linear 본문을 실제 읽은 시각: 2026-10-13 15:00:30.586 KST. 전체 조회 응답은 [보존 JSON](inputs/ade71-session-linear-20261013.json)에 있다.

| 자료 | 확인한 updatedAt (KST) |
|---|---|
| [ADE-71](https://linear.app/ade0033/issue/ADE-71) | 2026-10-13 14:42:34.495 |
| [ADE-55](https://linear.app/ade0033/issue/ADE-55) | 2026-10-13 14:42:31.135 |
| [ADE-97](https://linear.app/ade0033/issue/ADE-97) | 2026-10-13 12:43:03.424 |
| [ADE-100](https://linear.app/ade0033/issue/ADE-100) | 2026-10-13 14:42:34.495 |
| [최종 규격](https://linear.app/ade0033/document/인지동-최종-공통규격-v100-rgbdepthimu라벨학습-실행-기준-a3b36c5035c8) | 2026-10-13 14:43:22.751 |

10/13 본문은 core schema_version=1.0.0 및 기존 5개 스키마를 유지한다. 로컬 10/8 규격·스키마·contract.py와 대조해 core는 변경하지 않고 RGB/annotation 보조 파일만 별도로 검사한다. 보조 파일의 정확한 패키지 enum·도구 호환성은 0.2.0 수신 후 추가 대조한다. 이번 basis 형식은 **이 처리 모듈의 로컬 인수 sidecar**이며 팀 공통 규격으로 확정한 것이 아니다. 근거 파일의 내용이 물리적으로 정확하다는 승인까지 해시 검사로 대신하지 않는다.

적용 AGENTS.md는 드라이브·관련 부모 및 프로젝트 코드/문서 하위에서 발견되지 않았다. `C:\study\injidong_contract_v1`은 없다. `C:\study\injidong-depth-viewer`는 존재하지만 Git 저장소가 아니며 기존 환경·소스·ZIP·추가 사본을 보존했다. 구현은 기존 등록 worktree `C:\study\injidong-ade71-stage1-20261013`에 새 파일로만 추가했다. 기존 branch `codex/ade-71-stage1-20261013` / HEAD `a6180a6aca48de5c98b3a4d81619f64cea573118`, remote 없음. 새 브랜치가 필요하지 않아 전환하지 않았다. HEAD는 이전 검토 문서 커밋이며 현재 src/tests/schemas 복사본은 이미 미추적이었다.

## 2. 구현 파일과 재사용 경계

| 새 파일 | 역할 |
|---|---|
| [src/session_pipeline.py](../src/session_pipeline.py) | 명시적 basis·원본/근거 SHA-256 → FramePacket 세션 → 공용 로더 재로드 → 반복 재생 → 전체 점군·ProcessingResult → 별도 검증 보고서 |
| [src/session_auxiliary.py](../src/session_auxiliary.py) | images/annotations의 session/frame/specimen·해시·dtype/shape·Depth 좌표 근거 검사, target_mask 인수 함수 |
| [tests/test_session_pipeline.py](../tests/test_session_pipeline.py) | 정상/실패 경계 21개; 임시 파일과 I/O mock 사용 |
| [scripts/make_ade71_session_intake.py](../scripts/make_ade71_session_intake.py) | 명확한 합성 raw/basis·실제 D405의 미완성 basis 생성; 기존 파일 생성 충돌 거부 |
| [scripts/make_ade71_mobile_boundary.py](../scripts/make_ade71_mobile_boundary.py) | Android 실행이 없는 합성 모바일 인수 예제; 원본 RGB 미정렬·수작업/모델 mask 파일 구분 |
| [scripts/verify_ade71_auxiliary.py](../scripts/verify_ade71_auxiliary.py) | 기존 저장 세션의 보조 파일을 읽기 전용으로 검사; 입력 밖 새 보고서·종료 코드 |
| [scripts/ade71_session_inventory.py](../scripts/ade71_session_inventory.py) | 원본 프로젝트·기존 ZIP·출력·스키마의 시작/최종 해시 대조 |

기존 `depth_preflight.load_raw/strict_json/check_hash/new_run/write_json_new`, `contract.normalize_depth/FramePacket/validate_frame/point_cloud_camera/volume_preflight/validate_json`, `viewer_data.read_session` → `iter_frames/load_frame`, `replay.compare_frame/file_hashes/positive_int`를 재사용했다. 기존 depth_preflight·contract·replay·뷰어·보호 스키마·체크섬은 수정하지 않았다. 표시 축소·색상·보간은 이 저장 경로에 없다.

출력은 `outputs/ade71_sessions/run_<UUID>/`마다 독점 생성한다.

```text
run_<UUID>/
  evidence/basis.json, <hashed evidence copies>
  session/frames.jsonl
  session/raw/source.npz
  session/frame_000000/metadata.json
  session/frame_000000/arrays.npz
  results/frame_000000/points.npz
  results/frame_000000/processing.json
  validation.json
```

core metadata에 근거용 임의 키를 추가하지 않는다. source_frame_index·원본 key·원본 SHA-256·프레임 대응은 basis와 validation.json에 남긴다. metadata.storage.sha256는 새 NPZ의 실제 해시로 갱신한다. 원본 capture_time/host_receive_time/capture_source/provenance를 보존하고 replay_time은 반복별 보고서에만 기록한다. 무효 Depth는 기존 정규화 정책의 0이며 전체 배열·mask를 `numpy.array_equal`로 비교한다.

기본 status=failure이며 모든 저장·재로드·좌표·해시·보존 비교 후에만 passed가 된다. source/basis/evidence 원본 안에 출력하지 않는다. 생성은 x/xb와 새 디렉터리로 한다. 검증 중에는 pending_session/pending_results 및 processing.pending.json에 둔다. 최종 validation.pending.json 저장이 성공한 뒤 공개 폴더/결과 이름으로 전환하고 validation.json을 마지막에 공개한다. 중간 실패는 새 실행의 frames.jsonl을 frames.failed.jsonl로, 이미 공개한 processing.json을 processing.uncommitted.json으로 바꿔 부분 파일을 보존하면서 공용 세션 진입점을 닫는다. 보고서까지 쓸 수 없으면 stderr·종료 1이며 성공 메시지를 내지 않는다. 보고서를 만들 수 있는 변환 실패는 validation.json에 실제 원인을 기록한다. 격리 rename 자체도 실패하면 오류로 종료하며 파일 잠금/디스크 고장의 물리 시험을 수행했다고 주장하지 않는다. 완료 여부는 최종 validation.json 통과 상태와 공개 세션을 함께 확인한다.

## 3. 실행 환경·테스트·종료 코드

실제 Windows Python 보고: `Windows-10-10.0.26200-SP0`, Python 3.11.9, NumPy 2.3.5, Pillow 12.3.0. 호출은 `C:\study\injidong-ade71-stage1-20261013\.venv\Scripts\python.exe`; 이 .venv는 `C:\study\injidong-depth-viewer\.venv`로 연결된 기존 junction이다. 새 설치/업그레이드/가상환경 생성은 하지 않았다. 기본 PATH의 `python`은 C:\Python314\python.exe라서 재현 명령은 기존 venv를 명시한다.

실제 import는 `C:\study\injidong-ade71-stage1-20261013\src\contract.py`, NumPy는 `C:\study\injidong-ade71-stage1-20261013\.venv\Lib\site-packages\numpy\__init__.py`다. sys.prefix·executable·실제 명령·stdout/stderr·종료 코드는 아래 실행 JSON 및 validation.json에 보존했다. `-B -X utf8`로 기존 코드에 bytecode를 추가하지 않았다.

| 실행 | 결과/종료 | 근거 |
|---|---|---|
| 새 경계 테스트 최종 인터페이스 버전 | 21개 OK / 0 | [로그](../logs/1791871950259881200_ade71_session_interface_tests.json) |
| 기존 contract | 28개 OK / 0 | [로그](../logs/1791871855541441600_ade71_session_test_contract.json) |
| 기존 preprocessing boundaries | 4개 OK / 0 | [로그](../logs/1791871855307157800_ade71_session_test_preprocessing_boundaries.json) |
| 기존 replay | 10개 OK / 0 | [로그](../logs/1791871864597472500_ade71_session_test_replay.json) |
| 합성 정식 세션·점군·10회 재생 | passed_file_boundary_validation / 0 | [로그](../logs/1791871951405955200_ade71_session_final_synthetic.json) |
| 실제 D405 배열 재검사 | 10프레임 passed_array_preflight / 0 | [로그](../logs/1791871803915192700_ade71_session_actual_array.json) |
| 실제 D405 정식 변환 | INTAKE_BLOCKED / 1 | [로그](../logs/1791871803100754000_ade71_session_d405_blocked.json) |
| 합성 RGB·annotation 보조 파일 검사 | passed_auxiliary_file_checks / 0 | [로그](../logs/1791871855254490300_ade71_session_auxiliary.json) |

이번 고유 테스트 범위는 **21+28+4+10=63개**다. 중간 19개/21개 실행은 구현 확장 및 최종 process_frame 인터페이스 변경 검증 이력으로 남기고 합산하지 않는다. 전체 뷰어/GUI 모음은 변경하지 않아 반복하지 않았다. 과거 67개는 stage1 15 + contract28 + preprocessing4 + replay10 + viewer-output10이고 viewer16은 제외됐다. 과거 68개는 기존 28+4+10+10+16 범위다. 이번 63개와 같은 집합이 아니다.

실패 테스트는 단위 미확인·ray 거리·전체 무효·65535 의미 미확인·누락 보정/반올림/출처 불일치·해시 불일치·프레임 대응 오류·임의 core 키·shape·파일 경로 탈출·반복 중 저장 점군 변조·잘못된 전체 좌표·배열/점군 저장·로더/보고서 실패 및 CLI 실패 종료를 검사했다. I/O 실패는 mock이며 실제 디스크 고장을 시험한 결과가 아니다.

## 4. 합성 및 실제 D405 결과

최종 합성 결과: [validation.json](../outputs/ade71_sessions/run_48f48171aaca43eca55bc5e2e091d2b1/validation.json). raw=[[1000,1000],[1000,0]], scale=.001, fx=fy=100, cx=cy=0. 유효 픽셀 행 우선 (v,u)=(0,0),(0,1),(1,0), 저장 `points_m`는 float32 3×3이다. 전체 재로드 좌표가 [[0,0,1],[.01,0,1],[0,.01,1]] m와 일치하고 계산값 재로드는 허용 오차 0, 명시적 기대값은 rtol=0/atol=1e-7 m다. 파일 SHA-256=`ac26008fba6d8b9accc1afed052f82e47d7355babfacff44a6b6557e326c3cc6`. 10회 모두 전체 depth/mask/metadata/점군·개수·해시 일치, 입력 세션 파일 변화 없음. volume_m3=null, 이유 TARGET_UNAVAILABLE이다.

실제 원본 `C:\Users\AISW-510-131\Downloads\depth_original.zip` 및 기존 stage1 보존 원본·receipt·검사 보고서를 읽었다. 기존 SDK 수집 코드는 텍스트로만 확인했고 실행/import하지 않았다. 새 [실제 배열 검사](../outputs/ade71_session_array_recheck/run_8c2929812b2742a5b1d4842242539bfb/inspection_report.json)는 ZIP CRC/SHA-256·3개 내부 파일 해시·uint16 10×480×640·SDK SCALE 행 `9.999999747378752e-05`·전체 float32 depth/bool mask 저장 재로드를 통과했다. ZIP SHA-256=`c7db1884aa5a78fd4fd634153e9575912d762000a7aa0aa1ad7acee66889e6e2`이며 전후 동일하다. 내부 해시는 기존 [receipt](inputs/ade71-d405-20261013.json)와 일치한다.

프레임별 raw=65535 개수는 6645,6288,7172,5752,5422,6140,5265,5748,6456,6957이다. 기존 arithmetic 사전 검사는 finite·양수 정책으로 이 값을 포함하지만 **정상 거리/광축 Z로 승인하지 않는다**. 새 정식 변환 경계는 의미 미확인 65535가 있으면 거부한다. 실제 보정 근거 없이는 이 배열 사전 검사 출력에 Point Cloud를 적용하지 않았다.

## 5. 정식 실제 입력의 차단 원인과 담당

실제 [차단 보고서](../outputs/ade71_sessions/run_5cdc12857ae645298548634b78dcc121/validation.json)는 성공 상태가 아니며 session/frames.jsonl·실제 점군을 만들지 않았다.

| 항목 | 상태·담당 |
|---|---|
| 정밀 Depth 내참수 | metadata 문자열 f[384.78 384.78], p[315.857 237.279]는 반올림. 원본 SDK 정밀값/활성 profile: 도형준 제공, 강석현 검토 |
| rectified pinhole/광축 Z 근거 | Brown Conrady [0 0 0 0 0] 문자열만으로 호환 선언 불가. profile 보정·계수 정밀값·rectification 경로: 강석현 backend 검토, 도형준 수집 |
| 장비/profile/calibration 식별 | 수집 스크립트는 640×480 Z16 30 설정만 보임. 실제 모델/serial/FW/SDK·profile ID/calibration 연결 근거 부족: 도형준·강석현 |
| raw=65535 | 해당 실제 profile 의미와 처리 근거 부족. 제거/정상 거리 어느 쪽도 확정하지 않음: 강석현·도형준 |
| 촬영/수신 시간 | 원본에 미저장. 기존 프레임은 fully-null timestamp 객체로 보존 가능하고 변환 시각으로 대체하지 않음. 신규 수집 기록: 강석현 backend·도형준, 모바일 이가영 |
| 시편/조건/RGB/pose | 기존 원본에 없음. specimen/pose는 계약상 null 가능하나 시편 학습/평가 인수에는 자료 필요. 가짜 ID/RGB/자세를 생성하지 않음: 시편·small_v1 강석현, 실제 수집 도형준 |
| 실제 모바일 | Galaxy S23 FE는 사용자 확인. 모델번호·Android/One UI·USB host/SDK/연결 결과 미확인. ADE-100에서 이가영이 실제 자료 전달 |

**시각·시편 ID·pose·RGB 미확보 자체를 core의 non-null 필수 필드라고 오해하지 않는다.** 정식 D405 변환을 실제로 막는 것은 정밀 내참수·Depth 보정/semantics·장비/profile 출처·65535 의미 근거다. 원본에 없던 시각을 소급 생성할 수 없으므로 새로 촬영한 세션의 시각 자료와 구분한다.

부피는 target/support plane/plane basis/footprint/grid/coverage/방법 가정 확보 후 별도 구현·검증한다. 이번 성공한 ProcessingResult의 stage는 point_cloud이며 volume_m3/volume_method=null이다. 모델·실측 g가 없어 중량 평가나 정확도 완료를 주장하지 않는다. small_v1은 최대 25×25×30mm, 먼저 20mm cube/빈 바닥 예비 확인은 강석현, 실제 원본은 도형준이 수집한다. 옛 cm 시편 계획을 적용하지 않았다.

## 6. 이가영 인수 점검표와 입출력 예제

실제 인수 시 아래 자료를 묶어 받는다. 메시지 발송은 하지 않았다.

- ADE-100 실연결 근거: Galaxy S23 FE 모델번호, Android/One UI, 연결 방식(direct USB / PC 전달 / saved), 카메라 모델/FW/serial/SDK, USB 전력·권한·실제 성공/오류 로그.
- 공용 입력: session/frame ID·capture_source·real/synthetic, 원본 raw/해시/key/프레임 순서, SDK scale·raw invalid 값 의미, 정밀 Depth profile 내참수·calibration/rectification·광축 Z 근거.
- 시간/기록: 원본 capture_time/host_receive_time·clock_domain/origin, 미수집은 null. IMU 로그·시계 매핑/외참수는 이가영 담당; pose/sync 미검증은 카메라 좌표 단일 프레임만 처리.
- RGB: 원본/정렬 파일 별도, PNG RGB8/해시, images.jsonl의 session/frame/time/pair evidence/calibration/alignment. 크기 일치나 단순 resize는 정렬 승인 아님. 미수집 실제 RGB 행을 만들지 않음.
- mask: Depth H×W bool NPZ, annotations.jsonl의 session/frame/specimen·source/version/purpose·해시. manual_ground_truth/model_output은 별도 파일·버전. RGB 기반 mask의 좌표/시각 근거가 부족하면 인수 보류. target 안 결측을 제거하지 않음.

[합성 모바일 파일 예제](../examples/ade71_mobile_boundary_synthetic/SYNTHETIC_NOTICE.json)의 RGB는 2×2 RGB8이지만 미정렬/unverified이며 Depth 라벨에 사용 가능하다고 표시하지 않았다. 별도로 만든 Depth 좌표 합성 manual/model mask는 각각 2×2 bool, 4개 대상 픽셀 중 결측 1개를 그대로 포함한다. [보조 파일 결과](../logs/ade71_session_20261013/auxiliary.json)에서 이를 확인했다. specimen_id=null이며 실제 시료·모델 예측이라고 주장하지 않는다.

로컬 변환 basis 구조는 [실행 가능한 합성 basis](../examples/ade71_session_intake/synthetic/basis.json)를 따른다. `source`의 file/key/dtype/shape/sha256, `conversion`의 scale_to_m/semantics/invalid_values/raw_65535_policy, `frames`의 source_frame_index/완전한 v1 metadata/선택 target를 받는다. source 경로는 basis 디렉터리 안 상대 경로다. 원본은 새 intake 디렉터리에 해시 확인 복사한 뒤 사용한다. 완성 core metadata는 공용 스키마를 직접 검사한다. 저장 관련 SHA-256만 출력 값으로 교체한다.

실제 근거 sidecar의 `evidence_files`는 `{"evidence_id":{"file":"relative/path","sha256":"actual hash"}}`다. `real_geometry`에는 scale/semantics/intrinsics/rectification/device_profile를 각각 그 evidence_id로 참조하고, intrinsics_precision="full_precision", metadata와 일치하는 calibration_id/depth_profile_id 및 source_sha256를 입력한다. 이 값은 확인한 실제 파일/주장으로만 채운다. 65535가 있을 때 invalid 또는 valid_distance 정책과 raw_65535_evidence가 필요하다. optional target는 file/sha256/depth_alignment_evidence와 frame_id/session_id/specimen_id/source/version을 받으며 packet과 일치해야 한다. 직접 real process_frame/verify_session 호출도 basis_path를 받아 원본 프레임·전체 depth/valid/target·metadata와 다시 대조한다. 실제 attach_target 호출에는 같은 식별·출처/버전과 mask 파일/해시·정렬 근거 파일/해시를 담은 receipt/evidence_base가 필요하다. 이 구조는 물리 보정 승인이나 공용 패키지 형식 확정이 아니며 검토자가 근거 파일 내용을 별도 평가해야 한다. RGB/annotation 파일 자동 복사는 이 raw 변환 CLI의 구현 범위가 아니며 수신된 저장 세션의 보조 파일은 별도 validator로 인수한다.

공용 로더와 처리 모듈 호출 예제(합성 출력만 사용):

```python
from pathlib import Path
import sys
sys.path.insert(0, r'C:\study\injidong-ade71-stage1-20261013\src')
from contract import load_frame
from session_pipeline import process_frame
frame = load_frame(Path(r'C:\study\injidong-ade71-stage1-20261013\outputs\ade71_sessions\run_48f48171aaca43eca55bc5e2e091d2b1\session\frame_000000\metadata.json'))
# output_dir는 아직 존재하지 않는 새 경로를 전달한다.
result = process_frame(frame, {'output_dir': r'C:\study\injidong-ade71-stage1-20261013\outputs\new_handoff_example',
                               'config_version': 'ade71-file-v1'})
# result: v1 ProcessingResult; stage=point_cloud, unit=m, frame=camera,
# point_count=3, volume_m3=null. SDK 객체나 labels/실측 g를 입력하지 않는다.
```

## 7. 다음 실행 명령·공용 패키지 수신 체크

다음 PowerShell은 기존 fixture를 읽고 UUID 출력만 추가한다. generator는 예제 생성 시 이미 실행했으며 다시 실행하면 기존 예제를 덮어쓰지 않고 실패한다.

```powershell
Set-Location -LiteralPath 'C:\study\injidong-ade71-stage1-20261013'
& .\.venv\Scripts\python.exe -B -X utf8 src\session_pipeline.py `
  --basis examples\ade71_session_intake\synthetic\basis.json `
  --output-root outputs\ade71_sessions --repeat 10 `
  --expected-points examples\ade71_session_intake\synthetic\expected_points.json
$LASTEXITCODE # 정상 0

& .\.venv\Scripts\python.exe -B -X utf8 src\session_pipeline.py `
  --basis examples\ade71_session_intake\d405_blocked\basis.json `
  --output-root outputs\ade71_sessions --repeat 3
$LASTEXITCODE # 근거 미수신 상태의 의도된 실패 1

& .\.venv\Scripts\python.exe -B -X utf8 src\depth_preflight.py `
  'C:\Users\AISW-510-131\Downloads\depth_original.zip' `
  --receipt docs\inputs\ade71-d405-20261013.json `
  --output-root outputs\ade71_session_array_recheck
$LASTEXITCODE # 배열 검사 정상 0; 정식 세션/광학 보정 승인이 아님

$auxReport = 'logs\ade71_auxiliary_' + [guid]::NewGuid().ToString('N') + '.json'
& .\.venv\Scripts\python.exe -B -X utf8 scripts\verify_ade71_auxiliary.py `
  examples\ade71_mobile_boundary_synthetic --report $auxReport
$LASTEXITCODE # 파일 경계 정상 0; Android/정렬 실검증 아님

& .\.venv\Scripts\python.exe -B -X utf8 -m unittest discover `
  -s tests -p test_session_pipeline.py -v
$LASTEXITCODE
```

공용 Python 패키지 0.2.0은 미수신이다. 확인 범위: 현재 채팅 루트·위 두 injidong 관련 프로젝트 및 하위 사본의 파일명, 관련 Downloads 파일명, 기존 venv의 injidong distribution 목록(없음). 관련 경로에 software/injidong_week3 또는 docs/week3_quickstart.md를 발견하지 못했다. 호스트 전체 존재 여부까지 단정하지 않는다. 패키지 명령/API를 추측하거나 backend를 재구현하지 않았다.

수신 후 강석현과 확인할 목록:

- 다운로드 묶음·software/injidong_week3·docs/week3_quickstart.md 존재, 패키지 version 0.2.0과 core 1.0.0 구분.
- 배포 SHA-256/내부 manifest·코드 출처·지원 Python/OS/SDK·실제 모델별 지원 목록.
- 5개 보호 스키마·FramePacket/로드/저장/재생·npz key/경로/단위/invalid 정책 호환성.
- images.jsonl/annotations.jsonl의 필드/nullable/enum·source/time/정렬 근거·모델 mask 전달 방식.
- 실제 read_capture 산출물의 원본 scale/내참수/rectification·시각·해시를 이번 로더/전체 좌표 비교에 연결. quickstart에서 확인한 명령만 실행.

## 8. 보존·미수행 범위

시작 인벤토리는 [485개 파일 해시](../logs/ade71_session_20261013/start.json)이며 stage1·기존 depth-viewer·현재 채팅 루트와 다운로드 원본 ZIP을 포함한다(.git/.venv/__pycache__ runtime 제외). 최종 [보존 비교](../logs/ade71_session_20261013/preservation.json)는 기존 파일 변경/삭제 0을 확인한다. 기존 제출 ZIP·원본·기존 출력·스키마·문서·체크섬을 보존했고 새 파일/출력만 추가했다. tracked/staged diff 없음, branch/HEAD/remote 불변. reset/clean·삭제·stage/commit/push·Linear 수정·메시지 발송은 하지 않았다.

기존 verify_viewer_outputs.verify_preservation(None)도 직접 실행해 배포 체크섬 21개와 기준 문서·5개 스키마의 JSON 일치를 통과했다(종료 0). [보호 계약 확인](../logs/ade71_session_20261013/protected_contract.json). 보고서의 로컬 링크도 전부 존재한다.

이번에 수행하지 않은 항목은 실제 SDK/USB/카메라 캡처, Android 앱·휴대폰 실연결·IMU logger, GUI 시연, 실제 RGB 수집/Depth 정렬, 실제 Point Cloud, 관측 부피 적분·정확도, 모델 학습/실측 g 기반 중량 검증, 0.2.0 패키지 호환성·공식 통합/강석현 승인이다.
