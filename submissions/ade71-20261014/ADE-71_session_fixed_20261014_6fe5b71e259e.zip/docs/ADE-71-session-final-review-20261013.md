> 2026-10-14 정정: 10/13 ZIP 독립 검토의 추가 결함4건을 수정했습니다. 현재 판정·시험·보호 사본 영향·과거504개 미확인은 [10/14 수정서](ADE-71-zip-fixes-20261014.md)를 따릅니다. 아래는 당시 기록이며 현재 완료 판정으로 단독 사용하지 않습니다.

# ADE-71 세션 구현 제출 전 최종 검토

2026-10-13, Asia/Seoul. 결론: **수정한 PC 파일 처리 경계·합성 검증·실제 D405 차단 근거 범위로 제출 가능**하다. 실제 공용 세션/Point Cloud, Android/SDK 실연결, 부피/중량 및 팀장 승인 완료는 아니다.

## 발견 사항과 수정

먼저 코드·기존 저장 결과·문서·로그를 대조했고 기존 통과 테스트 모음부터 반복하지 않았다. [읽기 전용 감사 기록](../logs/ade71_session_review_20261013_audit.json)에서 기존 합성 성공 출력 2건·D405 차단 1건, 전체 depth/mask/점군·해시·원본 capture_time/source·반복 기록을 확인했다. D405 배열 출력 10개도 원본 raw와 재정규화한 전체 값 및 receipt/보고서 해시에 일치했다. 실제 배열 변환 CLI는 재실행하지 않았다. 합성 모바일 RGB/annotations도 현재 저장 파일과 보고서가 일치했다.

| 발견 | 수정 전 재현 / 영향 | 수정 |
|---|---|---|
| 부분 출력이 정상 세션처럼 읽힘 | 전체 기대 점군 불일치로 최종 failure인 데도 frames.jsonl이 존재하고 공용 로더가 읽음. 최종 보고서 저장 실패에도 같은 현상 | pending_session/results에서 검증, 최종 보고서를 먼저 준비 후 공개. 실패 시 새 실행의 manifest를 frames.failed.jsonl로 바꾸고 canonical processing.json도 uncommitted로 격리 |
| 직접 real 처리 근거 우회 | 변환 CLI를 통하지 않고 mock real FramePacket을 process_frame에 넣으면 보정 근거 없이 success 점군 생성 | 직접 process_frame/verify_session도 real은 basis_path 필수. 원본 해시·원본 프레임·정밀/보정/profile 주장·전체 depth/valid/target·metadata 대조를 처리 전에 수행 |
| 최초 재로드 프레임 수 누락 | zip(prepared,reloaded)는 짧아진 재로드 목록의 뒤쪽을 검사하지 않음 | ID·개수·순서 일치를 먼저 검사. 축소된 최초 로더 결과를 mock으로 거부 확인 |
| target/보조 파일 연결 검사 부족 | target NPZ에 dtype/shape·해시는 있지만 frame/session/specimen/source/version receipt 연결이 없음. 동일 core source/version annotation의 전체 mask 불일치도 통과 가능 | target receipt 식별/출처/버전 검사·전체 mask 대조. 실제 attach_target도 hashed receipt/정렬 근거 필수. 동일 core target provenance annotation은 전체 값 대조 |
| 보조 파일 경로/형식 | JSONL 자체 경로를 검사하지 않음. verified pair에 true 같은 값, alignment_method 숫자, 잘못된 ID 타입 등 | JSONL에도 relative_file 적용, verified pair는 원본 시각·설명 근거 요구, alignment/ID/source/version 타입·빈 문자열 검사, 중복 frame/purpose/version 거부 |

수정 전 문제 3건은 **백업한 수정 전 코드 + 임시 합성 fixture/mock real 표기**로 재현했다. 실제 카메라를 실행하거나 실제 D405를 임의 보정해서 얻은 결과가 아니다. code/source/provenance 내용의 물리적 타당성까지 해시로 승인하지 않는다. real_geometry의 full_precision과 evidence ID가 채워졌다는 것은 입력 주장/파일 연결 검사이며 강석현의 실제 근거 검토는 별도로 필요하다.

수정 파일은 src/session_pipeline.py, src/session_auxiliary.py, tests/test_session_pipeline.py의 보고서 실패 mock 대상 이름, 기존 구현 문서다. 새 회귀 테스트·감사 스크립트·검토 기록을 추가했다. 수정 전 파일은 logs/ade71_session_review_20261013_before에 별도 보존했다. core 스키마·기존 제조사 backend·뷰어·replay·depth_preflight·기존 합성 입력·기존 출력/로그·원본 ZIP을 수정하지 않았다.

## 공개와 실패 동작

1. raw/basis/evidence/target 조건은 세션 폴더 생성 전에 검사한다. 실제 D405의 현재 차단 basis는 근거 사본과 failure 보고서만 남기고 pending_session/session/Point Cloud를 생성하지 않는다.
2. 조건을 통과한 입력은 pending_session의 FramePacket 파일을 공용 로더로 재로드하고 pending_results의 전체 점군을 비교한다. 최초·반복 재로드의 모든 frame ID/순서, dtype/shape/전체 배열, 전체 float32 Nx3 점군·개수·SHA-256·m, 원본 파일 보존을 검사한다.
3. ProcessingResult는 검증 중 processing.pending.json이다. 원본 capture/host_receive/capture_source는 변하지 않고 replay_time은 검증 보고서의 반복 행에만 기록된다.
4. 모든 검사 후 validation.pending.json을 새 파일로 저장한다. 새 실행 안에서만 session/results/processing.json 이름으로 공개한 뒤 validation.json을 마지막 공개한다. 존재하는 목적지는 덮어쓰지 않는다.
5. 중간 저장·재로드·기대 점군·재생·원본 보존·최종 공개 오류는 status=failure, 종료 1이다. 새 실행의 frames.jsonl은 frames.failed.jsonl, 이미 공개한 processing.json은 processing.uncommitted.json으로 이름을 바꿔 보존한다. 따라서 실패한 새 세션은 일반 iter_frames/read_session 진입점으로 읽히지 않는다. validation.uncommitted.json 등은 버려진 시도의 기록이고 정상 최종 보고서가 아니다.
6. 보고서 I/O도 불가능하면 보고서가 없거나 불완전할 수 있고 stderr/종료 1로 실패한다. 예외를 성공 0으로 숨기지 않는다. 격리 rename 자체가 거부되는 실제 파일 잠금·권한/디스크 고장은 물리적으로 시험하지 않았다. 강제 중단·시스템 전원 차단까지 원자적 트랜잭션으로 보장한 구현은 아니다. 완료 인수는 **최종 validation.json의 passed 상태 + 공개 세션/전체 파일 대조**를 함께 사용한다.
7. standalone verify_session은 기존 입력을 수정하지 않고 새 결과를 pending 상태로 만든다. 직접 process_frame은 해당 프레임의 저장·전체 점군 재로드 성공을 반환하며, 세션 전체 재생/제출 완료를 대신하지 않는다.

원본/출력 경로는 resolve 후 검사하고 입력 디렉터리 안 출력·상대 경로 이탈·drive/UNC/ADS·symlink 이탈을 거부한다. 기존 출력 디렉터리/파일은 x/xb 및 새 UUID로 보존한다. JSONL·PNG·NPZ 참조도 상대 경로/해시를 확인한다. 변환 basis에 RGB/annotation 파일을 자동 복사하는 기능은 없으며, 공용 backend가 저장한 세션의 보조 파일을 별도 검사한다.

RGB 미수집은 행 없음, 원본 RGB 미정렬은 aligned_to_depth=false와 null 정렬 근거다. 같은 크기·resize를 정렬로 승인하지 않는다. verified pairing에서 원본 시각/설명 근거를 요구하는 것은 이 로컬 인수 guard이며 패키지 0.2.0 보조 파일 구조/enum 호환성은 수신 후 대조한다. target_mask와 valid_mask는 목적이 다르고 대상 안 결측 1개가 합성 manual/model mask에 그대로 남아 있다. 매칭된 core target source/version의 sidecar mask는 전체 값도 같아야 한다. 모델 출력을 manual_ground_truth로 변경하거나 중량 예측 성공으로 바꾸지 않는다.

## 이번 검증과 로그

환경은 기존 venv Python 3.11.9 / NumPy 2.3.5다. 새 패키지 설치·SDK·Android·GUI·촬영·학습은 수행하지 않았다.

| 최종 검사 | 결과 | 근거 |
|---|---|---|
| 추가 회귀 | **14개 통과, 1개 skip**, 종료 0 | [15개 선택 로그](../logs/1791873280281561600_ade71_submission_review_target_binding.json) |
| 변경에 직접 관련된 기존 테스트 | **9개 통과**, 종료 0 | [선택 로그](../logs/1791873346191062500_ade71_submission_review_selected.json) |
| 수정 후 합성 변환·전체 점군·10회 재생·공개 | passed_file_boundary_validation, 종료 0 | [로그](../logs/1791873344358923600_ade71_submission_review_synthetic.json), [출력](../outputs/ade71_submission_review/run_7f21f502a6c04fa0beab6a87bb33f28a/validation.json) |
| 수정 후 실제 D405 정식 변환 차단 | INTAKE_BLOCKED, 종료 1; 세션·점군 없음 | [로그](../logs/1791873344463132400_ade71_submission_review_d405_blocked.json), [출력](../outputs/ade71_submission_review/run_67b6abc96566486ebbed38ad401c966e/validation.json) |
| 합성 RGB/annotation 파일 경계 | passed_auxiliary_file_checks, 종료 0 | [로그](../logs/1791873344258735000_ade71_submission_review_auxiliary.json), [보고서](../logs/ade71_submission_review_auxiliary.json) |
| 기존+새 저장 출력·로그 전체 대조 | 출력 5건, D405 기존 배열 10개 일치, 종료 0 | [최종 출력 감사](../logs/ade71_submission_review_final_output.json) |

파일 symlink 생성 시험은 WinError 1314(권한 부족)로 skip했다. path resolve 가드·일반 경로 탈출은 검사했지만 실제 파일 symlink를 만들고 통과했다고 기록하지 않는다. 모든 I/O 실패 주입은 임시 파일/mock이며 실제 디스크 고장 시험이 아니다.

최초 추가 테스트 실행은 fixture 클래스를 직접 import해 기존 21개도 발견되는 선택 오류가 있었고, raw_input 추출 중 남은 invalid 인수 참조가 NameError로 실패했다([실패 로그](../logs/1791873042707473300_ade71_submission_review_regressions.json), 종료 1). 인수를 conversion에서 명시적으로 전달하도록 수정하고, fixture는 모듈로 import해 추가 테스트만 선택하도록 수정했다. 이 실패나 중간 13/14개 통과 실행을 최종 성공 개수에 합산하지 않는다. 최종 검증은 14+9=23개 성공, 1개 skip이다. 과거 63/67/68개 테스트 집합을 다시 통과했다고 주장하지 않는다.

## 담당자별 요청 자료

필수와 조건부를 구분한다. 모든 자료는 해당 촬영본의 원본 해시·session/frame/source_frame_index와 연결해 받아야 한다. 메시지는 발송하지 않았다.

| 필수 항목 / 적용 조건 | 해당 촬영본과 연결할 근거 | 받을 사람 |
|---|---|---|
| **필수:** 원본 raw 및 프레임 대응 | ZIP/NPZ SHA-256, key/dtype/N×H×W, source_frame_index ↔ frame/session ID. 기존 D405 receipt와 다른 촬영은 새 receipt | 도형준; 모바일은 이가영 |
| **필수:** scale와 optical_axis_z | 실제 SDK get_depth_scale 값/출력, 실행 코드·SDK/profile 정보, 해당 raw SHA-256. ray distance이면 먼저 보정한 Z 산출 근거 | 강석현 backend 검토, 도형준 수집; 모바일 이가영 전달 |
| **필수:** 정밀 Depth 내참수 | width/height/fx/fy/cx/cy 정밀 수치, 활성 Depth profile ID·calibration ID·원본 파일/프레임 범위. 반올림 콘솔 문자열 불가 | 도형준 제공, 강석현 확인 |
| **필수:** rectified_pinhole/왜곡 처리 | 해당 장비/profile의 원본 왜곡 모델·정밀 계수·보정/rectification 경로, 적용 intrinsics/calibration ID, 변환 전후 raw 대응. Brown Conrady의 자동 호환 선언 불가 | 강석현 확인, 도형준 원본 |
| **필수:** 장비/profile 출처 | 모델/serial/FW/SDK/OS·활성 Depth 설정·profile 식별과 해당 session/raw 해시를 함께 저장한 SDK 로그. D405라는 전달 표기만으로 대체 불가 | 도형준, 강석현; Android 조합은 이가영 |
| **해당 raw에 65535 존재 시 필수:** 의미/정책 | 해당 profile에서 65535가 invalid인지 valid 거리인지의 SDK/장비 근거와 정책 버전, source_sha256/profile/calibration ID | 강석현 확인, 도형준 수집; 모바일 이가영 |
| **신규 촬영 인수:** 원본 capture/host_receive 시간 | 프레임별 ns 문자열·clock_domain/origin, source frame 대응. 기존 미저장본은 fully-null 객체 유지하며 소급 생성 금지 | 강석현 backend·도형준; 모바일 이가영 |
| **데이터셋/평가 인수:** small_v1 시편/조건 | 실제 물리 specimen ID·촬영표·측정 치수/단위·조건·원본 해시. 20mm cube/빈 바닥 예비 자료 먼저. 기존 원본 미확인은 null | 강석현 시편 기준·예비 확인, 도형준 실제 촬영 |
| **실제 모바일 주장 시 필수:** Galaxy S23 FE 조합 | 실제 모델번호·Android/One UI·SDK/USB·전력/권한·성공/오류 로그와 ADE-100 session/frame/raw. PC 전달/saved/synthetic 구분 | 이가영 |
| **RGB 기반 라벨/mask 인수 시 필수:** 정렬·pair 근거 | 원본/정렬 PNG 별도 해시·RGB8·images.jsonl, Depth frame/calibration ID, 원본 시각·시계 매핑/대응과 실제 projection/alignment 방법. 크기만 맞춤 불가 | 이가영 자료·강석현 계약 검토 |
| **target 사용 시 필수:** frame-bound mask receipt | H×W bool NPZ/해시, frame/session/specimen, source/version/purpose와 정렬 근거 해시. model_output은 model/annotation 버전과 동일 입력 연결, manual은 별도 파일 | 이가영 |
| **세계 좌표/다중 시점 사용 시 조건부:** pose/sync | camera→world 보정·pose/capture 시각·clock mapping/evidence와 offset/uncertainty/tolerance. orientation으로 위치 생성 불가 | 강석현·도형준; IMU 원본은 이가영 |
| **부피 계산 시 조건부:** support/basis/footprint/coverage/가정 | 같은 FramePacket/target의 지지면·plane basis·측정 footprint·grid·완전 관측/방법 제한 근거 | 강석현 기준 검토, 도형준 촬영, 이가영 mask; 박수용 후처리 |
| **중량 정확도 주장 시 조건부:** 모델·실측 g | 실제 specimen별 모델/feature 버전·학습/독립 split·실측 기기/방법/해시. 미확보 0g 생성 금지 | 이가영 모델·평가, 강석현 실측 기준 |
| **패키지 호환성 확인 시 필수:** 공용 0.2.0 묶음 | software/injidong_week3·docs/week3_quickstart.md·배포 해시·core1.0.0·지원/호환 목록. 미수신 상태 유지 | 강석현 |

촬영 시각·pose·시편/RGB 미확보는 core의 nullable 규칙을 따른다. 현재 실제 D405 정식 변환의 차단 원인은 **정밀 내참수·광학/단위 보정 근거·장비/profile 출처·65535 의미**이며, 단순히 timestamp가 없어서라고 보고하지 않는다.

## 실행 명령과 제출 범위

```powershell
Set-Location -LiteralPath 'C:\study\injidong-ade71-stage1-20261013'
& .\.venv\Scripts\python.exe -B -X utf8 -m unittest discover `
  -s tests -p test_session_submission_review.py -v
$LASTEXITCODE

& .\.venv\Scripts\python.exe -B -X utf8 src\session_pipeline.py `
  --basis examples\ade71_session_intake\synthetic\basis.json `
  --output-root outputs\ade71_submission_review --repeat 10 `
  --expected-points examples\ade71_session_intake\synthetic\expected_points.json
$LASTEXITCODE # 0

& .\.venv\Scripts\python.exe -B -X utf8 src\session_pipeline.py `
  --basis examples\ade71_session_intake\d405_blocked\basis.json `
  --output-root outputs\ade71_submission_review --repeat 3
$LASTEXITCODE # 근거 미수신 입력은 1
```

제출물은 수정 코드·로컬 basis/target receipt 설명·명확한 합성 인수 예제·새 정상/실패 실행 로그·기존 D405 원본 해시/배열 사전 검사·차단 사유·이 검토서다. **이번 범위 제출 가능** 판정이며 공식 통합·강석현 승인과 구분한다. 실제 입력 완료 판정은 위 필수 자료의 촬영본 연결을 검토한 뒤 같은 경로의 정식 변환·공용 재로드·반복 재생·전체 점군/해시/m 비교를 실제 파일로 성공해야 한다. RGB/mask·pose·부피·중량은 해당 추가 조건을 별도로 만족해야 한다.

## 보존과 Git

이번 시작 [471개 파일 인벤토리](../logs/ade71_session_review_20261013_start.json)를 기준으로 수정 허용한 4개 파일만 바뀌었는지 [최종 대조](../logs/ade71_submission_review_preservation.json)에서 확인했다. 기존 출력·로그·합성 인수 예제·D405 원본/다운로드 ZIP·제출 ZIP·보호 스키마와 체크섬은 변경/삭제하지 않았다.

지난 구현의 485개 시작 목록과 이번 시작 목록을 비교하면, 이전에 존재하던 `C:\study\injidong-depth-viewer\injidong-ade71-stage1-20261013` 하위 사본 97개는 **이번 검토 시작 전에 이미 없음**을 확인했다. 생성/제거 주체·시각은 미확인이다. 이번 검토가 삭제한 것으로 기록하지 않으며 임의 복구도 하지 않았다. 나머지 당시 파일의 해시는 이번 시작과 동일했다. 따라서 과거 보존 기록을 지금 모든 사본이 존재한다는 주장으로 사용하지 않는다.

branch `codex/ade-71-stage1-20261013`, HEAD `a6180a6aca48de5c98b3a4d81619f64cea573118`, remote 없음. HEAD 추적 문서의 unstaged/staged diff 없음이며 이번 구현 파일은 원래부터 미추적이었다. reset/clean·commit/push·Linear 수정·메시지 발송·기존 파일 정리/삭제를 하지 않았다.
