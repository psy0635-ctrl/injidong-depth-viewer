# ADE-71 ZIP 직접 검토 4건 수정·소스 검증 — 2026-10-14

PC 파일 처리 경계의 4건을 수정했다. 새 회귀와 공용 로더 영향 시험은 **104 pass / 0 failure / 2 skip**이다. 합성 변환·저장·재로드·10회 재생·전체 Point Cloud 비교는 종료0, 실제 D405는 여전히 `INTAKE_BLOCKED`·종료1이며 정상 세션/점군은 없다. 이 문서는 10/13 구현·최종 검토의 해당 완료 판정을 정정한다. 공식 병합·팀장 승인·실제 카메라/Android/부피/중량 완료는 아니다. 새 제출 ZIP 실물의 해시/CRC·별도 해제본 실행 기록은 새 제출 폴더의 `PACKAGING_VERIFICATION.json`으로 구분한다.

## 기준·수정 전 재현

검토 기준은 `reviews/zip_review_20261013_0b3e707a3db3/REVIEW.md`다. 해당 재현 코드를 변경 없이 새 임시 경로에 복사해 **수정 전 코드**로 7개 관찰과 3개 거부 guard를 다시 실행했다. 이전 ZIP의 코드와 현재 수정 시작 소스 hash도 대조했다. 결과는 `reviews/ade71_fixes_20261014_d74f61/before_reproduction`이다. mock real은 합성 배열과 가짜 장비 선언을 사용한 시험이며 실제 보정 근거가 아니다.

최신 Linear 최종 규격 및 ADE-71/55/97/100/99를 10/14 직접 재조회했다. 제목은 **인지동 최종 공통규격 v1.0.0 · RGB·Depth·IMU·라벨·학습 실행 기준**, 갱신은 2026-10-13 14:43:22.751 KST이며 조회 응답에 기록한 UTC 시각에 +09:00을 적용한다. 본문·갱신 시각은 10/13 검토 기준과 동일하다. 전체 응답은 이번 review의 `latest_linear.json`에 보존한다. core1.0.0, 박수용/이가영/강석현/도형준 분담, small_v1/20mm cube·빈바닥 예비 확인, 10/18·10/25 목표를 변경하지 않았다. 공용0.2.0 배포 묶음은 이 작업에 미수신이며 호환성 미확인이다.

## 결함별 수정 전후

| 결함 | 수정 전 직접 재현 | 수정 파일·함수 | 수정 후 |
|---|---|---|---|
| F1 raw hash/path/scale 불일치 | frame과 basis metadata를 같은 잘못된 값으로 맞추면 직접 API success·3점, CLI EVIDENCE_MISMATCH | `session_pipeline.prepare_frames`, `require_processing_basis`, `convert_frames` | 쓰기 없는 동일 검사 함수를 공유. 직접 API는 ContractError, CLI 종료1; 정상 points/처리 출력 생성 안 됨 |
| F2 report 공개+격리 연속 실패 | 종료1이지만 canonical manifest가 읽히고 processing success 잔존 | `session_boundary.guard_read/guard_packet`, 활성 `contract.load_frame/iter_frames/validate_frame`, `viewer_data.read_session`, `run_conversion` | 같은 잔존 파일을 남기는 실패를 주입해도 final commit 부재로 SESSION_UNCOMMITTED. 재생은 failure 반환·0회, 직접 처리·점군 계산도 거부 |
| F3 출력/입력 충돌 | 직접 output_dir가 intake 안이어도 success, CLI는 거부 | `session_boundary.disjoint_output`, `packet_input_dirs`, pipeline `input_directories`·process/verify/conversion | 동일·자식·부모 방향 모두 resolve 후 거부. loader가 기억한 세션 경로와 basis/raw/evidence/target 폴더에도 적용. 실제 Windows junction 별칭 거부 확인 |
| F4 내부 절대 manifest 경로 | 공용 iter_frames는 내부 absolute 수용, wrapper만 거부 | 공통 `session_boundary.relative_path`, 활성 `contract._inside` | 내부를 가리켜도 absolute/drive/UNC/ADS/.. 거부. 정상 상대 legacy 세션·합성 cloud 유지 |

모든 core metadata/frames 형식과 5개 스키마는 그대로다. raw·전체 depth/mask/target 배열, 프레임 대응·원본 시각/출처, 정밀/보정 evidence 요구·65535 정책, 미계산 volume=null·미준비 모델 규칙도 그대로다. 65535의 finite 양수 산술 통계는 해당 profile의 정상 거리 승인이 아니다.

## 완료 공개 절차와 지원 진입점

새 실행은 검증 전 run에 `.ade71-run.json`, 세션에 `.ade71-session.json`을 만든다. 이는 **프로젝트 파일 공개 프로토콜 sidecar**이며 core 필드 추가나 팀 규격 변경이 아니다. pending 세션 읽기는 생성자의 내부 ContextVar staging 문맥에서만 허용한다. CLI/config에는 bypass 옵션이 없다.

검증·원본 보존 확인 후 validation.pending.json을 저장하고 session/results·processing.json·validation.json을 공개한다. 마지막으로 해시 연결 완료 기록 `.ade71-complete.pending.json`을 닫은 뒤 `.ade71-complete.json`으로 rename한다. 완료 기록은 validation hash, manifest hash, 전체 processing.json hash를 연결한다. 공개 로더는 이 마지막 파일의 존재·형식·hash·report passed/errors/repeat·result success를 검사한다. `validation.json`만의 passed나 JSON의 processing success 문자열만으로 완료 인수하지 않는다.

final report 공개 실패+첫 격리 rename 실패에서도 완료 파일은 생성되지 않는다. 남은 canonical 파일을 `contract.iter_frames/load_frame`, `viewer_data.read_session`, `replay.verify_replay`, `pipeline.verify_session/process_frame`, `point_cloud_camera`, `session_boundary.load_processing_result`가 정상 입력으로 승인하지 않는 것을 시험했다. 로더 packet에는 런타임 원본 경로만 기억하며 metadata에 넣지 않는다. 캐시된 packet과 attach_target 사본도 이 출처 문맥을 보존한다.

격리는 증거 보존·오인 방지의 보조 절차다. 안전성은 격리 성공에만 의존하지 않는다. partial completion write도 final completion이 아니며 종료1이다. 임의 시스템 종료·전원 차단·파일 시스템 durability를 물리 시험한 것은 아니다. sidecar는 파일 완료 확인 수단이며 인증/서명/물리 보정 승인이 아니다. 고의로 보호 sidecar를 삭제하고 raw JSON으로 packet을 재구성하는 행위는 지원 파일 읽기 API가 아니다. 파일에서 처리할 때 지원 loader를 사용한다. 외부 backend의 정상 legacy core 세션에는 이 프로젝트 marker를 강제하지 않는다; 기존 세션 API/nullable 규칙의 호환성을 유지한다.

직접 메모리 합성 packet에는 자동 추론할 원본 폴더가 없다. 입력 파일에서 만든 packet은 loader의 경로 문맥 또는 basis/input_dir를 전달한다. real은 basis 필수이며 잘못된 내부 scale/path/hash를 승인하지 않는다. 외부 root 안에서 입력을 품는 출력 ancestor도 일관되게 거부하는 보수적 정책이다. 기존 파일 배치를 이동/정리하지 않는다. resolve는 실행 당시 기존 symlink/junction ancestor를 따른다. 다른 프로세스가 검사 직후 별칭을 바꾸는 경쟁이나 공격자 변조를 방어하는 파일 handle 기반 보안 API로 주장하지 않는다.

## 공용 보호 파일과 호환 영향

`src/contract.py`가 보호 checksum 목록에 있다는 것을 확인했다. wrapper에만 검사를 추가하면 직접 공용 import와 replay에 우회가 남으므로 **활성 프로젝트 사본의 로더/validate 경계 연결부를 변경**했다. 공용 수학·스키마·정규화 구현은 재사용한다. 원본은 `protected_reference/src/contract.py`와 이번 시작 before 사본에 byte-for-byte 보존했다. original SHA256=`f69426b2b62310994d835dc5f9a8166d8fc893a42c985bae823609e610aeb5de`다. diff를 제출에 포함한다.

5스키마, 기존 `SHA256SUMS.txt`, 다른 20 보호 기준 파일은 변경하지 않았다. 기존 checksum 파일을 활성 contract.py에 그대로 적용하면 **의도한 1건 mismatch**다. 숨기거나 checksum을 바꾸지 않는다. 새 `PROTECTED_FILE_MAP.json`은 이 원본 한 건을 protected_reference 경로에 매핑하고, 활성 사본을 변경 사본으로 별도 기록한다. 원본 checksum 검사와 활성 구현 검사 결과를 구분한다. 보호 사본은 기록용이며 지원 runtime import 경로가 아니다.

일반 relative legacy session과 기존 함수 서명·FramePacket core 필드는 유지한다. 오류 입력의 절대경로 수용을 거부하도록 강화하고 관리 세션에는 완료 gate가 추가됐다. 보호 공용 로더 사본 변경 및 새로운 sidecar 프로토콜의 공용0.2.0 통합 영향은 **강석현 최종 검토 필요**다. 현재 로컬 프로젝트에서의 통과를 팀장 승인으로 표현하지 않는다.

## 실행 환경·시험 수

기존 `C:\study\injidong-depth-viewer\.venv\Scripts\python.exe` 사용. Windows10.0.26200, Python3.11.9/NumPy2.3.5/Pillow12.3.0; viewer 영향 시험에는 기존 Matplotlib 환경도 사용했다. 새 환경 설치·SDK/Android 실연결·GUI 수동 시연·학습은 하지 않았다.

| 최종 소스 시험 범위 | run | pass | skip | failure |
|---|---:|---:|---:|---:|
| 새 4결함 회귀 `test_session_zip_fixes.py` |16|15|1|0|
| 공용 `test_contract.py` |28|28|0|0|
| 세션/보조 `test_session_pipeline.py` |21|21|0|0|
| 이전 수정 회귀 `test_session_submission_review.py` |15|14|1|0|
| 공용 로더 영향 `test_replay.py` |10|10|0|0|
| 뷰어 영향 `test_viewer.py` |16|16|0|0|
| 이번 최종 소스 합계 |106|104|2|0|

실제 디렉터리 symlink 신규 시험과 기존 annotations.jsonl 파일 symlink 시험은 WinError1314로 skip이다. 통과로 합산하지 않았다. Windows junction 생성은 권한 변경 없이 가능하여 신규 회귀에서 실제 별칭 거부를 확인했다. 기존 로그의 skip1과 이번 skip2는 범위가 다르다. 새 ZIP 해제본의 4결함 회귀 재실행은 별도 기록으로, 이 소스 시험 합계에 중복 합산하지 않는다. 과거67/68·구현63·이전 추가14+9 기록도 이번 결과와 합산하지 않는다.

최초 신규 회귀 실행은 2 failure/1skip이었다. 하나는 viewer가 격리된 manifest를 먼저 읽어 INPUT_CORRUPT로 분류하는 순서 문제였고 completion 검사를 먼저 하도록 고쳤다. 다른 하나는 failure report를 반환하는 replay API에 예외를 기대한 시험 오류로, 실제 failure/0회/SESSION_UNCOMMITTED 반환을 검사하도록 정정했다. 최초 최소 CLI supervisor도 인수를 package 내부에 두어 prepare helper의 의도된 PATH_INVALID를 예상0과 잘못 비교한 실행 오류가 있었다. 외부 신규 intake 및 실제 archive/basis 인수를 사용하도록 수정한 뒤 새 실행은 종료0이다. 이 중간 실패를 성공 수에 포함하지 않으며, 실패 기록을 별도 evidence로 보존한다.

## 정상·차단 CLI

최종 최소 실행 report는 `outputs/ade71_zip_fixes_20261014/run_cb6c2c93bbe249ab99f9dc38bb11706c/validation.json`이다. 합성 raw 2×2·scale.001로 전체 depth/mask 및 독립 formula의 points_m을 다시 계산했다. float32 Nx3 points=`[[0,0,1],[.01,0,1],[0,.01,1]]`, 행 우선3점, m, NPZ 전체 값·count·hash가 일치한다. points SHA256=`ac26008fba6d8b9accc1afed052f82e47d7355babfacff44a6b6557e326c3cc6`. capture/host_receive/provenance를 보존하고 replay_time 분리와 반복10회를 확인했다.

같은 실행의 실제 D405는 원본 hash를 검사해 외부 임시 intake로 준비했다. capture10.py는 실행하지 않는다. real 정식 CLI는 INTAKE_BLOCKED·종료1이며 정상 manifest/points 없음이다. 정밀 내참수·Brown Conrady 보정·장비/profile/calibration 출처·65535 의미 부족이 차단 원인이다. 원본 미저장 capture/pose는 생성하지 않으며 시간 all-null을 촬영 시각으로 대체하지 않는다.

```powershell
Set-Location -LiteralPath 'C:\study\injidong-ade71-stage1-20261013'
& 'C:\study\injidong-depth-viewer\.venv\Scripts\python.exe' -B -X utf8 `
  scripts\validate_ade71_zip_fixes.py --output-root outputs\ade71_zip_fixes_20261014
$LASTEXITCODE # 최종 supervisor 0; 내부 합성0 / 실제차단1
```

## 보존·요청 자료·제출 범위

이번 시작 인벤토리는 447개 파일이며 .git/.venv/cache·이번 review 폴더 제외를 명시했다. 이번 허용 변경은 활성 src4개 및 정정 문서2개뿐이다. 새 모듈/회귀/실행 script·원본 사본·로그/출력·새 제출 자료는 추가 파일로 기록한다. 종료 전후 실제 목록/hash 대조 결과만 이번 보존 근거로 사용한다. **과거504개 전후 보존은 근거 미수신이며 확정하지 않는다.**

branch=`codex/ade-71-stage1-20261013`, HEAD=`a6180a6aca48de5c98b3a4d81619f64cea573118`는 10/3 문서 커밋이다. 구현 코드의 커밋이 아니고 미커밋/미추적 상태다. 원본 depth_original.zip, 옛 제출 ZIP과 기존 출력은 그대로다. 새 제출본은 별도 이름으로 만든다. commit/push/reset/clean·Linear 변경·메시지는 하지 않는다.

실제 완료에 필요한 요청표는 새 ZIP의 REQUESTS.md와 기존 최종 검토서의 담당자별 요청표를 따른다. 모든 근거는 raw SHA256=`61de8af2f76ff04e4bac639b7f1fe4f4a07b638534dec2ac8866deb657ad29f0`, index0..9 및 활성 profile/calibration과 연결돼야 한다. 도형준: 원본·프레임 대응·정밀내참수/장비 로그·시편 촬영. 강석현: scale/Z·보정/65535 정책 확인, 원본연결·공용0.2.0·공용 변경 사본 검토, small_v1 제작/실측. 이가영: 실제 Galaxy S23 FE 모델번호/OS/SDK/USB 결과·RGB/Depth/정렬·mask/모델 자료. 수용: 인수 후 정식 conversion/replay/cloud 후처리. 시간/pose 부재만으로 단일 카메라 좌표 처리를 금지하지 않는다. 부피는 지지면/plane basis/footprint/coverage·방법 가정, 중량은 실제 모델/실측g/독립 specimen split이 추가로 필요하다.

**제출 범위:** 이번4결함 수정, PC파일·합성 검증·실제 입력 차단 및 실패 경계 증거를 팀장 검토용으로 제출한다. 실제 D405 세션/Point Cloud·Android/SDK·부피·중량 완료나 최종 공용 승인으로 확대하지 않는다. 새 ZIP의 실물 검증 성공은 별도 PACKAGING_VERIFICATION 기록으로 확인한다.
